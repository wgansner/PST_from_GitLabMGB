sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;
			service.colOrderUrl = null;
			service.colOrderSystemId = null;
			service.colOrderSystemClnt = null;

			service.getCollectiveOrderLink("", "");

			return service;
		},

		getCollectiveOrderLink: function (sSystemId, sSystemClnt) {
			/*
			service.oModel.read("/CollectiveOrderURLSet(SystemId='" + sSystemId + "',SystemClnt='" + sSystemClnt + "')", {
				success: function (oData) {
					service.colOrderUrl 		= oData.UrlCol;
					service.colOrderSystemId	= oData.SystemId;
					service.colOrderSystemClnt	= oData.SystemClnt;
				},
				error: function (oError) {
					jQuery.sap.log.error(oError);
				}
			});
			*/
			var href = window.location.href;
			var hash = "/sap/";
			var stringArray = href.split(hash);
			service.colOrderUrl = stringArray[0] + "/sap/bc/gui/sap/its/webgui?" + "&~TRANSACTION=%2aZOI_SAMMEL_FROMPRSS%20";
		},

		createCollectiveOrderLink: function (guid, parameters) {
			var finalUrl = service.colOrderUrl + "P_GUID=" + guid;
			$.each(parameters, function (key, val) {
				finalUrl = finalUrl + ";" + key + "=" + val;
			});

			service.controller.getModel("oPreisModel").setProperty("/s_LinkColOrderTransGUID", finalUrl);
		}
	};
});