sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		getUnitOfMeasures: function (materialnumber) {
			var deferred = $.Deferred();
			var number = materialnumber;
			var matNo;
			var selectedTab = service.controller.getModel("oPreisModel").getProperty("/selectedTab");
			if (selectedTab === "but" && number === 2) {
				matNo = service.controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/AltMaterialNumber");
			} else {
				matNo = service.controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/MaterialNumber" + number);
			}
			var salesOrganisation = service.controller.getModel("oPreisModel").getProperty("/general/SalesOrganisation");
			var distributionChannel = service.controller.getModel("oPreisModel").getProperty("/general/DistributionChannel");
			var aFilters = [];

			if (matNo !== "") {
				aFilters.push(new Filter("Material", FilterOperator.EQ, matNo));
			}
			if (salesOrganisation !== "") {
				aFilters.push(new Filter("SalesOrganisation", FilterOperator.EQ, salesOrganisation));
			}
			if (distributionChannel !== "") {
				aFilters.push(new Filter("DistributionChannel", FilterOperator.EQ, distributionChannel));
			}

			service.oModel.read("/UoMF4Set", {
				filters: aFilters,
				success: function (oData) {
					var selectedKey;
					$.each(oData.results, function (key, val) {
						if (val.Default) {
							selectedKey = val.UoM;
						}
					});
					if (selectedTab === "but" || selectedTab === "glb") {
						number = "";
					}
					var materialPath = number !== "" ? "material" + number : "";
					service.controller.getModel("unitOfMeasureModel").setProperty("/" + selectedTab + "/" + materialPath, oData.results);
					service.controller.getModel("oPreisModel").setProperty("/" + selectedTab + "/UoM" + number, selectedKey);
					deferred.resolve(oData);
				}
			});

			return deferred.promise();

		}
	};
});