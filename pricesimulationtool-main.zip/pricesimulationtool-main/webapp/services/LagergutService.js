sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		getLagergutSet: function (oView) {
			var deferred = $.Deferred();
			var equipmentLagergut = oView.getModel("i18n").getResourceBundle().getText("EquipmentLagergut");
			service.oModel.read("/LagergutF4Set", {
				success: function (oData) {
					var aResults = [{
						Key: "",
						Name: equipmentLagergut
					}];
					$.each(oData.results, function (key, val) {
						aResults.push(val);
					});
					service.controller.getModel("lagergutModel").setProperty("/results/", aResults);
					deferred.resolve(oData.results);
				}
			});

			return deferred.promise();

		}
	};
});