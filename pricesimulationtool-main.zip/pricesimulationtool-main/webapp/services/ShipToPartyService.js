sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		getShipToPartySet: function () {
			var deferred = $.Deferred();
			var selectedTab = service.controller.getModel("oPreisModel").getProperty("/selectedTab");
			var soldToParty = service.controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/SoldToParty");
			var salesOrganisation = service.controller.getModel("oPreisModel").getProperty("/general/SalesOrganisation");
			var distributionChannel = service.controller.getModel("oPreisModel").getProperty("/general/DistributionChannel");
			var division = service.controller.getModel("oPreisModel").getProperty("/general/Division");
			var aFilters = [];
			if (soldToParty !== "") {
				aFilters.push(new Filter("SoldToParty", FilterOperator.EQ, soldToParty));

			}
			if (salesOrganisation !== "") {
				aFilters.push(new Filter("SalesOrganisation", FilterOperator.EQ, salesOrganisation));

			}
			if (distributionChannel !== "") {
				aFilters.push(new Filter("DistributionChannel", FilterOperator.EQ, distributionChannel));

			}
			if (division !== "") {
				aFilters.push(new Filter("Division", FilterOperator.EQ, division));

			}

			service.oModel.read("/ShipToPartySearchSet", {
				filters: aFilters,
				success: function (oData) {
					var shipToPartyModel = new sap.ui.model.json.JSONModel();
					var data = {
						path: "",
						results: oData.results
					};
					shipToPartyModel.setData(data);
					service.controller.getView().setModel(shipToPartyModel, "shipToPartyModel");
					deferred.resolve(oData);
				}
			});

			return deferred.promise();

		}
	};
});