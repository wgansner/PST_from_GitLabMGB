
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;
			service.oPreisModel = service.controller.getModel("oPreisModel");

			return service;
		},

		initializeSalesOrganisationService: function () {
			var deferred = $.Deferred();
			var selectedTab = service.oPreisModel.getProperty("/selectedTab");
			var soldToParty = service.oPreisModel.getProperty("/" + selectedTab + "/SoldToParty");
			var arrFilters = [];

			if (soldToParty) {
				arrFilters.push(new Filter("SoldToParty", FilterOperator.EQ, soldToParty));
			}

			service.oModel.read("/SalesOrganisationF4Set", {
				filters: arrFilters,
				success: function (oData) {
					var aResults = [{
						Key: "--",
						Name: "--",
						SalesOrganisation: ""
					}];
					var selectedKey = "--";
					$.each(oData.results, function (key, val) {
						aResults.push(val);
						if (val.Default) {
							selectedKey = val.Key;
						}
					});
					service.oPreisModel.setProperty("/general/SalesOrganisation", selectedKey);

					var salesOrganisationSelectModel = new sap.ui.model.json.JSONModel(aResults);
					service.controller.setModel(salesOrganisationSelectModel, "salesOrganisationSelectModel");

					service.setDistChanelData(selectedKey).done(function () {
						deferred.resolve(oData);
					});
				}
			});
			return deferred.promise();
		},

		setDistChanelData: function (selSalesOrgValue) {
			var deferred = $.Deferred();
			var selectedTab = service.oPreisModel.getProperty("/selectedTab");
			var soldToParty = service.oPreisModel.getProperty("/" + selectedTab + "/SoldToParty");
			
			
			var aFilters = [
				new Filter("SalesOrganisation", FilterOperator.EQ, selSalesOrgValue)
			];
			if(soldToParty !== ""){	
				aFilters.push(new sap.ui.model.Filter("SoldToParty", FilterOperator.EQ, soldToParty));
			}
			aFilters.push(new sap.ui.model.Filter("Abteilung", FilterOperator.EQ, selectedTab.toUpperCase()));

			service.oModel.read("/DistributionChannelF4Set", {
				filters: aFilters,
				success: function (oData) {
					var aResults = [{
						Key: "--",
						Name: "--",
						SalesOrganisation: ""
					}];
					var selectedKey = "--";
					$.each(oData.results, function (key, val) {
						aResults.push(val);
						if (val.Default) {
							selectedKey = val.Key;
						}
					});
					service.oPreisModel.setProperty("/general/DistributionChannel", selectedKey);

					var distributionOptionModel = new sap.ui.model.json.JSONModel(aResults);
					service.controller.setModel(distributionOptionModel, "distributionOptionModel");

					service.setDivisionData().done(function () {
						deferred.resolve(oData);
					});
				},
				error: function (oError) {
					jQuery.sap.log.error(oError);
				}
			});
			return deferred.promise();
		},

		setDivisionData: function () {
			var deferred = $.Deferred();
			var selectedTab = service.oPreisModel.getProperty("/selectedTab");
			var salesOrganisation = service.oPreisModel.getProperty("/general/SalesOrganisation");
			var distributionChannel = service.oPreisModel.getProperty("/general/DistributionChannel");
			var soldToParty = service.oPreisModel.getProperty("/" + selectedTab + "/SoldToParty");

			var arrFilters = [];
			arrFilters.push(new sap.ui.model.Filter("Abteilung", FilterOperator.EQ, selectedTab.toUpperCase()));
			arrFilters.push(new sap.ui.model.Filter("SalesOrganisation", FilterOperator.EQ, salesOrganisation));
			arrFilters.push(new sap.ui.model.Filter("DistributionChannel", FilterOperator.EQ, distributionChannel));
			if(soldToParty !== ""){	
				arrFilters.push(new Filter("SoldToParty", FilterOperator.EQ, soldToParty));
			}

			service.oModel.read("/DivisionF4Set", {
				filters: arrFilters,
				success: function (oData) {
					var aResults = [{
						Key: "--",
						Name: "--",
						SalesOrganisation: ""
					}];
					var selectedKey = "--";
					$.each(oData.results, function (key, val) {
						aResults.push(val);
						if (val.Default) {
							selectedKey = val.Key;
						}
					});
					service.oPreisModel.setProperty("/general/Division", selectedKey);

					var divisionOptionModel = new sap.ui.model.json.JSONModel(aResults);
					service.controller.setModel(divisionOptionModel, "divisionOptionModel");

					service.setSalesOfficeData().done(function () {
						deferred.resolve(oData);
					});
				},
				error: function (oError) {
					jQuery.sap.log.error(oError);
				}
			});
			return deferred.promise();
		},

		setSalesOfficeData: function () {
			var deferred = $.Deferred();
			var selectedTab = service.oPreisModel.getProperty("/selectedTab");
			var salesOrganisation = service.oPreisModel.getProperty("/general/SalesOrganisation");
			var distributionChannel = service.oPreisModel.getProperty("/general/DistributionChannel");
			var division = service.oPreisModel.getProperty("/general/Division");
			var soldToParty = service.oPreisModel.getProperty("/" + selectedTab + "/SoldToParty");

			var arrFilters = [];
			arrFilters.push(new Filter("SalesOrganisation", FilterOperator.EQ, salesOrganisation));
			arrFilters.push(new Filter("DistributionChannel", FilterOperator.EQ, distributionChannel));
			arrFilters.push(new Filter("Division", FilterOperator.EQ, division));

			service.oModel.read("/SalesOfficeF4Set", {
				filters: arrFilters,
				success: function (oData) {
					var aResults = [{
						Key: "--",
						Name: "--",
						SalesOrganisation: ""
					}];
					var selectedKey = "--";
					$.each(oData.results, function (key, val) {
						aResults.push(val);
						if (val.Default) {
							selectedKey = val.Key;
						}
					});
					service.oPreisModel.setProperty("/general/SalesOffice", selectedKey);

					var salesOfficeOptionModel = new sap.ui.model.json.JSONModel(aResults);
					service.controller.setModel(salesOfficeOptionModel, "salesOfficeOptionModel");
					if (soldToParty !== "") {
						service.setCustomerSalesData().done(function () {
							deferred.resolve(oData);
						});
					} else {
						service.setSalesGroupData(selectedKey).done(function () {
							deferred.resolve(oData);
						});
					}
				},
				error: function (oError) {
					jQuery.sap.log.error(oError);
				}
			});
			return deferred.promise();
		},

		setSalesGroupData: function (sSalesOfficeValue) {
			var deferred = $.Deferred();

			service.oModel.read("/SalesGroupF4Set", {
				filters: [new sap.ui.model.Filter("SalesOffice", sap.ui.model.FilterOperator.EQ, sSalesOfficeValue)],
				success: function (oData) {
					var aResults = [{
						Key: "--",
						Name: "--",
						SalesOrganisation: ""
					}];
					var selectedKey = "--";
					$.each(oData.results, function (key, val) {
						aResults.push(val);
					});

					service.oPreisModel.setProperty("/general/SalesGroup", selectedKey);

					var salesGroupSelectModel = new sap.ui.model.json.JSONModel(aResults);
					service.controller.setModel(salesGroupSelectModel, "salesGroupSelectModel");

					deferred.resolve(oData);
				},
				error: function (oError) {
					jQuery.sap.log.error(oError);
				}
			});
			return deferred.promise();
		},

		setCustomerSalesData: function () {
			var deferred = $.Deferred();
			var selectedTab = service.oPreisModel.getProperty("/selectedTab");
			var soldToParty = service.oPreisModel.getProperty("/" + selectedTab + "/SoldToParty");
			var salesOrganisation = service.oPreisModel.getProperty("/general/SalesOrganisation");
			var distributionChannel = service.oPreisModel.getProperty("/general/DistributionChannel");
			var division = service.oPreisModel.getProperty("/general/Division");

			var parameters = "(";
			if (soldToParty && salesOrganisation && distributionChannel && division) {
				parameters = parameters + "SoldToParty='" + soldToParty + "',";
				parameters = parameters + "SalesOrganisation='" + salesOrganisation + "',";
				parameters = parameters + "DistributionChannel='" + distributionChannel + "',";
				parameters = parameters + "Division='" + division + "')";

				service.oModel.read("/CustomerSalesDataSet" + parameters, {
					success: function (oData) {
						service.oPreisModel.setProperty("/general/SalesOffice", oData.SalesOffice);
						service.setSalesGroupData(oData.SalesOffice).done(function (data) {
							service.oPreisModel.setProperty("/general/SalesGroup", oData.SalesGroup);
						});

						deferred.resolve(oData);
					},
					error: function (oError) {
						jQuery.sap.log.error(oError);
					}
				});
			}
			return deferred.promise();
		}

	};
});