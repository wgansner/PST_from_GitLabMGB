sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		getMaterials: function (materialNumber) {
			var deferred = $.Deferred();
			var selectedTab = service.controller.getModel("oPreisModel").getProperty("/selectedTab");
			var oPreisModel = service.controller.getModel("oPreisModel");
			var aFilters = [];
			var matNo = materialNumber;
			if(!materialNumber){
				materialNumber = "";
				matNo = 1;
			}
			aFilters.push(new Filter("Abteilung", FilterOperator.EQ, selectedTab.toUpperCase()));
			aFilters.push(new Filter("MaterialNumber", FilterOperator.EQ, matNo));

			if (oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber1") && matNo > 1) {
				aFilters.push(new Filter("MaterialNo1", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber1")));
			}
			if (oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber2") && matNo > 2) {
				aFilters.push(new Filter("MaterialNo2", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber2")));
			}

			service.oModel.read("/AlternativeMaterialSet", {
				filters: aFilters,
				success: function (oData) {
					deferred.resolve(oData);
				}
			});

			return deferred.promise();

		},
		
		getMaterialName: function(materialNo, material) {
			var deferred = $.Deferred();
			var selectedTab = service.controller.getModel("oPreisModel").getProperty("/selectedTab");
			var oPreisModel = service.controller.getModel("oPreisModel");
			var aFilters = [];
			var matNo;
			
			switch(materialNo){
				case "1":
					matNo = 1;
					// aFilters.push(new Filter("MaterialNo1", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber1")));
					break;
				case "2":
					matNo = 2;
					aFilters.push(new Filter("MaterialNo1", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber1")));
					// aFilters.push(new Filter("MaterialNo2", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber2")));
					break;
				case "3":
					matNo = 3;
					aFilters.push(new Filter("MaterialNo1", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber1")));
					aFilters.push(new Filter("MaterialNo2", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber2")));
					// aFilters.push(new Filter("MaterialNo3", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber3")));
					break;
				case "alt":
					matNo = 2;
					aFilters.push(new Filter("MaterialNo1", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber1")));
					// aFilters.push(new Filter("MaterialNo2", FilterOperator.EQ, oPreisModel.getProperty("/" + selectedTab + "/MaterialNumber2")));
					break;
			}
			aFilters.push(new Filter("Abteilung", FilterOperator.EQ, selectedTab.toUpperCase()));
			aFilters.push(new Filter("MaterialNumber", FilterOperator.EQ, matNo));

			service.oModel.read("/AlternativeMaterialSet", {
				filters: aFilters,
				success: function (oData) {
					var matName = "";
					var number = "MaterialNo" + matNo;
					var description = "Description" + matNo;
					$.each(oData.results, function(key, val){
						if(val[number] === material){
							matName = val[description];
						}	
					});
					deferred.resolve(matName);
				}
			});

			return deferred.promise();

		}
	};
});