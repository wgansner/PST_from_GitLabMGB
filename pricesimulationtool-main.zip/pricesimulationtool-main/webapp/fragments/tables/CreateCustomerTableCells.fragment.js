sap.ui.define([
		"sap/ui/layout/form/Form",
		"sap/ui/layout/form/FormContainer",
		"sap/ui/layout/form/FormElement",
		"sap/m/Input",
		"sap/m/Label",
		"sap/m/Column"
	],
	function (
		Form,
		FormContainer,
		FormElement,
		Input,
		Label,
		Column
	) {
		"use strict";

		sap.ui.jsfragment("ch.migrol.oi.PriceSimulationTool.fragments.tables.CreateCustomerTableCells", {
			createContent: function (oController) {
				var columns = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{customerSearchModel>Partner}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>Title}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>FullName}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>PostalCode}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>Region}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>Country}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>City}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>Street}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>HouseNo}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>District}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>Telephone1}"
						}),
						new sap.m.Text({
							text: "{customerSearchModel>Telephone2}"
						})
					]
				});

				return columns;
			}
		});
	});