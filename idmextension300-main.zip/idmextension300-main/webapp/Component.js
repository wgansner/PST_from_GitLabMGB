jQuery.sap.registerResourcePath("ico/lib", "/sap/bc/ui5_ui5/sap/ds_scsdlibs");
jQuery.sap.declare("s4idm.DS_IDMUIExtension.Component");

//START OF EXTENSION 

var patchConfigLoader = function (oConfigLoader) {
	oConfigLoader._appVersion = "3.0.1";
	oConfigLoader._fillConfigModel = function (configKey, response) {
		var config = (response.JSON) ? response.JSON : response;

		//START of Change models and dataComponent of Multifunction to extendedDocuments model
		if (configKey === "dataModels") {
			config.models.multiFunctionTool.dataComponent = "extendedDocuments";
		} else if (configKey === "dialogs") {
			config.dialogs.multiFunction.modelName = "extendedDocuments";
		}
		//END

		this._oConfigModel.setProperty("/".concat(configKey), config);
		return config;
	};

	oConfigLoader._prepareLocalPath = function (configPath) {
		var path = this._oManifest.resolveUri(configPath);
		//START of Change config path to Standard IDM
		if (path.indexOf("zoi_idm") >= 0) {
			path = "../ui5_ui5/sap/DS_IDMUI/" + configPath;
		}
		//END
		return path;
	};
};

(function () {
	var componentConstructor;
	var superPromiseConfiguration;

	Object.defineProperty(this.s4idm.DS_IDMUIExtension, "Component", {
		get: function () {
			return componentConstructor;
		},
		set: function (providedComponentConstructor) {
			superPromiseConfiguration = providedComponentConstructor.prototype._promiseConfiguration;

			providedComponentConstructor.prototype._promiseConfiguration = function () {
				patchConfigLoader(this._oConfigLoader);
				this._oConfigLoader._promiseMetaConfig();
				return superPromiseConfiguration.apply(this, arguments);

			};

			componentConstructor = providedComponentConstructor;
		}
	});
})();
//END OF EXTENSION

sap.ui.component.load({
	name: "s4idm",
	url: "/sap/bc/ui5_ui5/sap/DS_IDMUI",
	asyncHints: {
		libs: ["ico.lib"]
	}
});

this.s4idm.Component.extend("s4idm.DS_IDMUIExtension.Component", {
	metadata: {
		manifest: "json"
	}
});