sap.ui.controller("s4idm.DS_IDMUIExtension.controller.MultiFunctionCustom", {
	optimizeColumns: function (oEvent) {
		var oTable = this._oSmartTable.getTable();
		var oTpc =  oTable._getPointerExtension();
		var aColumns = oTable.getColumns();
		for (var i = 0; i < aColumns.length; i++) {
			oTpc.doAutoResizeColumn(i);
		}
	},
	onFilterBarInitialise: function() {
		//	console.log("onFilterBarInitialise");
            
            setTimeout(this._setDefaultFilters.bind(this), 0);
        },
	onMultiFunctionAfterOpen: function() {
            this.getOwnerComponent().getUpdateQueue().executeUpdates();
          /*  if(!this._oPopupModel.getProperty("/preFilters")){
            	this._oSmartTable.rebindTable(true);
            }else{
            	this.rebindNeded = true;
            }*/
         //   console.log("onMultiFunctionAfterOpen");
            this._setDefaultFilters(); 	this._oSmartTable.rebindTable(true); 
        },
     _setDefaultFilters: function() {
            var e = this._oPopupModel.getProperty("/preFilters");
            if (e && this._oFilterBar.isInitialised()) {
                this._oFilterBar.clear();
                Object.keys(e).forEach(function(i) {
                    this._oFilterBar.determineFilterItemByName(i).setVisibleInFilterBar(true);
                    this._oFilterBar.getControlByKey(i).setValue(e[i]); 
                }
                .bind(this));
                this._oFilterBar.fireSearch();
                if(this.rebindNeded){
            		this.rebindNeded = false;
            		this._oSmartTable.rebindTable(true);
                }
            }
        }
        
});