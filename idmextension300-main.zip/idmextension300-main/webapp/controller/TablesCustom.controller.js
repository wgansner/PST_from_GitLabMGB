sap.ui.controller("s4idm.DS_IDMUIExtension.controller.TablesCustom", {
	_extOptimizeColumns: function (oEvent) {
		$.each(this._oSplitter.getContent(), function (key, val) {
			var tableId = "table";

			var oTable = val.byId(tableId).getTable ? val.byId(tableId).getTable() : val.byId(tableId);
			var oTpc = oTable._getPointerExtension();
			var aColumns = oTable.getColumns();
			for (var i = 0; i < aColumns.length; i++) {
				oTpc.doAutoResizeColumn(i);
			}
		});
	}
});