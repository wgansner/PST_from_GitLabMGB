	/*global location history */
	jQuery.sap.require("ch.migrol.oi.PriceSimulationTool.utils.Constants");
	sap.ui.define([
		"./BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/routing/History",
		"ch/migrol/oi/PriceSimulationTool/model/formatter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"ch/migrol/oi/PriceSimulationTool/utils/Constants",
		"sap/m/Token",
		"sap/m/ColumnListItem",
		"sap/m/Label",
		"sap/m/MessageBox",
		"sap/ui/core/Fragment",
		"ch/migrol/oi/PriceSimulationTool/model/models",
		"ch/migrol/oi/PriceSimulationTool/services/OrganisationServices",
		"ch/migrol/oi/PriceSimulationTool/services/UnitOfMeasureService",
		"ch/migrol/oi/PriceSimulationTool/services/ShipToPartyService",
		"ch/migrol/oi/PriceSimulationTool/services/BuTService",
		"ch/migrol/oi/PriceSimulationTool/services/SuAService",
		"ch/migrol/oi/PriceSimulationTool/services/GlbService",
		"ch/migrol/oi/PriceSimulationTool/services/BusinessPartnerReferenceService",
		"ch/migrol/oi/PriceSimulationTool/services/MaterialService",
		"ch/migrol/oi/PriceSimulationTool/services/BusinessPartnerSearchService",
		"ch/migrol/oi/PriceSimulationTool/services/BusinessPartnerCreateService",
		"ch/migrol/oi/PriceSimulationTool/services/EquipmentService",
		"ch/migrol/oi/PriceSimulationTool/services/TelephoneSaleService",
		"ch/migrol/oi/PriceSimulationTool/services/CustomerTitleService",
		"ch/migrol/oi/PriceSimulationTool/services/LanguageService",
		"ch/migrol/oi/PriceSimulationTool/services/AuftragsgrundService",
		"ch/migrol/oi/PriceSimulationTool/services/BestellkanalService",
		"ch/migrol/oi/PriceSimulationTool/services/LagergutService",
		"ch/migrol/oi/PriceSimulationTool/services/BoilerSizeService",
		"ch/migrol/oi/PriceSimulationTool/services/TankSizeService",
		"ch/migrol/oi/PriceSimulationTool/services/CollectiveOrderService",
		"ch/migrol/oi/PriceSimulationTool/services/PostalCodeService",
		"ch/migrol/oi/PriceSimulationTool/services/ContractCreationService",
		"sap/m/MessageToast"
	], function (
		BaseController,
		JSONModel,
		History,
		Formatter,
		Filter,
		FilterOperator,
		Constants,
		Token,
		ColumnListItem,
		Label,
		MessageBox,
		Fragment,
		Models,
		OrganisationServices,
		UnitOfMeasureService,
		ShipToPartyService,
		BuTService,
		SuAService,
		GlbService,
		BusinessPartnerReferenceService,
		MaterialService,
		BusinessPartnerSearchService,
		BusinessPartnerCreateService,
		EquipmentService,
		TelephoneSaleService,
		CustomerTitleService,
		LanguageService,
		AuftragsgrundService,
		BestellkanalService,
		LagergutService,
		BoilerSizeService,
		TankSizeService,
		CollectiveOrderService,
		PostalCodeService,
		ContractCreationService,
		MessageToast
	) {
		"use strict";

		var controller;

		return BaseController.extend("ch.migrol.oi.PriceSimulationTool.controller.Worklist", {

			formatter: Formatter,

			/**
			 * Called when the worklist controller is instantiated.
			 * @public
			 */
			onInit: function () {
				controller = this;

				sap.ui.require("sap/m/MessageBox");

				// Add the worklist page to the flp routing history
				this.addHistoryEntry({
					title: this.getResourceBundle().getText("worklistViewTitle"),
					icon: "sap-icon://table-view",
					intent: "#PriceSimulationTool-display"
				}, true);

				// Attaches validation handlers
				sap.ui.getCore().attachValidationError(function (oEvent) {
					oEvent.getParameter("element").setValueState(sap.ui.core.ValueState.Error);
				});
				sap.ui.getCore().attachValidationSuccess(function (oEvent) {
					oEvent.getParameter("element").setValueState(sap.ui.core.ValueState.None);
				});

				// Message Processor has to be initialized and registered at MessageManager
				controller.oMessageProcessor = new sap.ui.core.message.ControlMessageProcessor();
				controller.oMessageManager = sap.ui.getCore().getMessageManager();
				controller.oMessageManager.registerMessageProcessor(controller.oMessageProcessor);

				// initialize Models
				controller.setModel(Models.setInitialCustomerSearchModel(), "customerSearchModel");
				controller.setModel(Models.setInitialAddressSuggestionSearchModel(), "addressSuggestionSearchModel");
				controller.setModel(Models.setInitialPreisModel("but"), "oPreisModel");
				controller.setModel(Models.setInitialUoMModel(), "unitOfMeasureModel");
				controller.setModel(Models.setInitialShiptToModel(), "shipToModel");
				controller.setModel(Models.setInitialPostalCodeModel(), "postalCodeModel");
				controller.setModel(Models.setInitialEquipmentModel(), "equipmentModel");
				controller.setModel(Models.setInitialPreisResultModel(), "preisResultModel");
				controller.setModel(Models.setInitialBPSearchRuleModel(), "businessPartnerSearchRuleModel");
				controller.setModel(Models.setInitialBPSearchRuleModel(), "businessPartnerCreateMandatoryModel");
				controller.setModel(Models.setInitialCustomerTitleModel(), "customerTitleModel");
				controller.setModel(Models.setInitialLanguageModel(), "languageModel");
				controller.setModel(Models.setInitialLagergutModel(), "lagergutModel");
				controller.setModel(Models.setInitialBoilerSizeModel(), "boilerSizeModel");
				controller.setModel(Models.setInitialTankSizeModel(), "tankSizeModel");
				controller.setModel(Models.setInitialCalculationModel(), "calculationModel");
			},

			onAfterRendering: function () {
				// initialize Services
				controller.organisationService = OrganisationServices.onInit(controller.getModel(), controller);
				controller.unitOfMeasureService = UnitOfMeasureService.onInit(controller.getModel(), controller);
				controller.shipToPartyService = ShipToPartyService.onInit(controller.getModel(), controller);
				controller.butService = BuTService.onInit(controller.getModel(), controller);
				controller.suaService = SuAService.onInit(controller.getModel(), controller);
				controller.glbService = GlbService.onInit(controller.getModel(), controller);
				controller.BPRefService = BusinessPartnerReferenceService.onInit(controller.getModel(), controller);
				controller.materialService = MaterialService.onInit(controller.getModel(), controller);
				controller.businessPartnerSearchService = BusinessPartnerSearchService.onInit(controller.getModel(), controller);
				controller.businessPartnerCreateService = BusinessPartnerCreateService.onInit(controller.getModel(), controller);
				controller.equipmentService = EquipmentService.onInit(controller.getModel(), controller);
				controller.telephoneSaleService = TelephoneSaleService.onInit(controller.getModel(), controller);
				controller.collectiveOrderService = CollectiveOrderService.onInit(controller.getModel(), controller);
				controller.contractCreationService = ContractCreationService.onInit(controller.getModel(), controller);
				controller.postalCodeService = PostalCodeService.onInit(controller.getModel(), controller);
				controller.customerTitleService = CustomerTitleService.onInit(controller.getModel(), controller);
				controller.languageService = LanguageService.onInit(controller.getModel(), controller);
				controller.auftragsgrundService = AuftragsgrundService.onInit(controller.getModel(), controller);
				controller.bestellkanalService = BestellkanalService.onInit(controller.getModel(), controller);
				controller.lagergutService = LagergutService.onInit(controller.getModel(), controller);
				controller.boilerSizeService = BoilerSizeService.onInit(controller.getModel(), controller);
				controller.tankSizeService = TankSizeService.onInit(controller.getModel(), controller);

				controller.organisationService.initializeSalesOrganisationService().done(function (oData) {
					controller.setModel(sap.ui.getCore().getModel("salesOrganisationSelectModel"), "salesOrganisationSelectModel");
					controller.setModel(sap.ui.getCore().getModel("distributionOptionModel"), "distributionOptionModel");
					controller.setModel(sap.ui.getCore().getModel("divisionOptionModel"), "divisionOptionModel");
					controller.setModel(sap.ui.getCore().getModel("salesOfficeOptionModel"), "salesOfficeOptionModel");
					controller.setModel(sap.ui.getCore().getModel("salesGroupSelectModel"), "salesGroupSelectModel");
				});

				controller.BPRefService.getBusinessPartnerReference();
				// controller.businessPartnerSearchService.getBusinessPartnerSearchRulesSet();
				controller.customerTitleService.getCustomerTitleSet();
				controller.languageService.getLanguageSet();
				controller.auftragsgrundService.getAuftragsgrundSet();
				controller.bestellkanalService.getBestellkanalSet();
				controller.lagergutService.getLagergutSet(this.getView());
			},

			onItemTabSelect: function (oEvent) {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				Models.setInitialPreisModel(selectedTab);
				Models.setInitialPreisResultModel();
				Models.setInitialPreisModelGeneralData();
				controller.toggleTelephoneSale();
				controller.toggleCollectiveOrder();
				controller.toggleContractCreation();
				controller.toggleSaveData();
				Models.setInitialShiptToModel();
				Models.setInitialPostalCodeModel();
				Models.setInitialUoMModel();
				controller.auftragsgrundService.getAuftragsgrundSet();
				controller.bestellkanalService.getBestellkanalSet();
				controller.organisationService.initializeSalesOrganisationService();
				controller.oMessageManager.removeAllMessages();
				controller.byId("butPostalCode").setValue("");
				controller.byId("glbPostalCode").setValue("");
				controller.byId("suaPostalCode").setValue("");
				controller.getModel("oPreisModel").setProperty("/showValidation", false);
				controller.getModel("oPreisModel").setProperty("/CustomerCreationEnabled", true);
			},

			onFormReset: function (oEvent) {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				controller.byId("priceResultTableBuT").removeSelections();
				controller.byId("priceResultTableGLB").removeSelections();
				controller.byId("priceResultTableSuA").removeSelections();
				Models.setInitialPreisModel(selectedTab);
				Models.setInitialShiptToModel();
				Models.setInitialUoMModel();
				Models.setInitialPreisResultModel();
				Models.setInitialPostalCodeModel();
				controller.auftragsgrundService.getAuftragsgrundSet();
				controller.bestellkanalService.getBestellkanalSet();
				controller.organisationService.initializeSalesOrganisationService();
				controller.oMessageManager.removeAllMessages();
				controller.byId("butPostalCode").setValue("");
				controller.byId("glbPostalCode").setValue("");
				controller.byId("suaPostalCode").setValue("");
				controller.getModel("oPreisModel").setProperty("/CustomerCreationEnabled", true);
			},

			onChangeSoldToParty: function (value) {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				controller.initializeSalesOrganisationService();

				controller.toggleTelephoneSale();
				controller.toggleCollectiveOrder();
				controller.toggleContractCreation();
				if (value !== "") {
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "Mandatory/PostalCode", false);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/PostalCodeEnabled", false);
				} else {
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "Mandatory/PostalCode", true);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/PostalCodeEnabled", true);
				}

				controller.businessPartnerSearchService.getName().done(function (oData) {
					var name = oData.CustomerText;
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/SoldToPartyName", name);
				});
				controller.autoGetShipToParty();

				// Verify if button Save Data can be enabled
				controller.toggleSaveData();

				controller.setCalculationDataSoldToParty();
			},

			autoGetShipToParty: function () {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				switch (selectedTab) {
				case "sua":
					controller.shipToPartyService.getShipToPartySet().done(function (oData) {
						$.each(oData.results, function (key, val) {
							if (controller.getModel("oPreisModel").getProperty("/sua/SoldToParty") === val.ShipToParty) {
								controller.getModel("oPreisModel").setProperty("/sua/ShipToParty", val.ShipToParty);
							}
						});
					});
					break;
				default:
					break;
				}
			},

			onChangePostalCode: function (value) {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				if (value !== "") {
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "Mandatory/SoldToParty", false);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "Mandatory/ShipToParty", false);
					controller.postalCodeService.getPostalCode(value, "").done(function (oData) {
						controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/PostalCodeCity", oData.ShipToPartyCity);
					}).fail(function () {
						controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/PostalCodeCity", "");
					});
				} else {
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "Mandatory/SoldToParty", true);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "Mandatory/ShipToParty", true);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/PostalCodeCity", "");
				}
			},

			initializeSalesOrganisationService: function () {
				controller.organisationService.initializeSalesOrganisationService();
			},

			getUnitOfMeasures: function (matNo) {
				controller.unitOfMeasureService.getUnitOfMeasures(matNo);
			},

			onStepInputChange: function (oEvent) {
				if (oEvent.getSource().getValue() > oEvent.getSource().getMax()) {
					oEvent.getSource().setValue(oEvent.getSource().getMax());
				}
				if (oEvent.getSource().getValue() < oEvent.getSource().getMin()) {
					oEvent.getSource().setValue(oEvent.getSource().getMin());
				}
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
			},

			onShipToTableAddPosition: function (oEvent) {
				var initialPosition = Models.getInitialShipToTablePosition();
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var soldToParty = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/SoldToParty");
				var postalCode = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/PostalCode");

				if (soldToParty === "") {
					controller.postalCodeService.getPostalCode(postalCode, soldToParty).done(function (oDataPostal) {
						initialPosition.ShipToPartyCity = oDataPostal.ShipToPartyCity;
						controller.getModel("shipToModel").getProperty("/results").push(initialPosition);
						controller.getModel("shipToModel").refresh(true);
					});
				} else {

					controller.shipToPartyService.getShipToPartySet().done(function (oData) {
						$.each(oData.results, function (key, val) {
							if (soldToParty === val.ShipToParty) {
								initialPosition.KunWeStreet = val.Shiptopartystreet;
								initialPosition.CustomerGroup = val.CustomerGroup;
								initialPosition.CustomerGroupName = val.CustomerGroupName;
								initialPosition.PLZ = val.PostalCode;
								initialPosition.ShipToPartyCity = val.ShipToPartyCity;
							}
						});
						controller.getModel("shipToModel").getProperty("/results").push(initialPosition);
						controller.getModel("shipToModel").refresh(true);
					});
				}

			},

			onShipToPartyVH: function (oEvent) {
				var selectedItemPath = "";
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				if (selectedTab === "but") {
					selectedItemPath = oEvent.getSource().getBindingContext("shipToModel").getPath();
				}

				controller.shipToPartyService.getShipToPartySet().done(function (oData) {
					controller.getModel("shipToPartyModel").setProperty("/path", selectedItemPath);
					if (!controller._shipToPartyDlg) {
						Fragment.load({
							name: "ch.migrol.oi.PriceSimulationTool.fragments.dialogs.ShipToPartySearchDlg",
							type: "XML",
							controller: controller
						}).then(function (dialog) {
							controller._shipToPartyDlg = dialog;
							controller.getView().addDependent(controller._shipToPartyDlg);
							controller._shipToPartyDlg.open();
						});
					} else {
						controller._shipToPartyDlg.open();
					}
				});
			},

			onShipToPartySelect: function (oEvent) {
				var selectedItemPath = controller.getModel("shipToPartyModel").getProperty("/path");
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");

				var selectedItem = oEvent.getSource().getSelectedItem();
				var postalCode = selectedItem.getBindingContext("shipToPartyModel").getProperty("PostalCode");
				var shipToPartyCity = selectedItem.getBindingContext("shipToPartyModel").getProperty("ShipToPartyCity");
				var shipToPartyNumber = selectedItem.getBindingContext("shipToPartyModel").getProperty("ShipToParty");
				var shipToPartyName = selectedItem.getBindingContext("shipToPartyModel").getProperty("ShipToPartyName");
				var shipToPartyStreet = selectedItem.getBindingContext("shipToPartyModel").getProperty("Shiptopartystreet");
				var shipToPartyCustomerGroup = selectedItem.getBindingContext("shipToPartyModel").getProperty("CustomerGroup");
				var shipToPartyCustomerGroupName = selectedItem.getBindingContext("shipToPartyModel").getProperty("CustomerGroupName");
				switch (selectedTab) {
				case "but":
					{
						controller.getModel("shipToModel").setProperty(selectedItemPath + "/PLZ", postalCode);
						controller.getModel("shipToModel").setProperty(selectedItemPath + "/ShipToPartyCity", shipToPartyCity);
						controller.getModel("shipToModel").setProperty(selectedItemPath + "/KunWe", shipToPartyNumber);
						controller.getModel("shipToModel").setProperty(selectedItemPath + "/KunWeName", shipToPartyName);
						controller.getModel("shipToModel").setProperty(selectedItemPath + "/KunWeStreet", shipToPartyStreet);
						controller.getModel("shipToModel").setProperty(selectedItemPath + "/CustomerGroup", shipToPartyCustomerGroup);
						controller.getModel("shipToModel").setProperty(selectedItemPath + "/CustomerGroupName", shipToPartyCustomerGroupName);
						break;
					}
				case "sua":
					{
						controller.getModel("oPreisModel").setProperty("/sua/ShipToParty", shipToPartyNumber);
						break;
					}
				}
				controller.onCancelDlg(oEvent);
			},

			onPostalCodeTableAddPosition: function (oEvent) {
				var initialPosition = Models.getInitialPostalCodeTablePosition();

				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var postalCode = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/PostalCode");

				initialPosition.PostalCode = postalCode;
				controller.getModel("postalCodeModel").getProperty("/results").push(initialPosition);
				controller.getModel("postalCodeModel").refresh(true);
			},

			onTableRemovePosition: function (oEvent, model) {
				var shipToModel = controller.getModel(model);
				var path = oEvent.getSource().getBindingContext(model).getPath();
				var index = path.slice(path.length - 1);
				var results = shipToModel.getProperty("/results/");

				results.splice(index, 1);
				shipToModel.refresh(true);
			},

			onCustomerCreateVH: function (oEvent) {
				Models.setInitialCustomerSearchModel();
				if (controller.byId("bpRefSearchTable")) {
					controller.byId("bpRefSearchTable").removeSelections(true);
				}
				if (!controller._createCustomerDlg) {
					Fragment.load({
						name: "ch.migrol.oi.PriceSimulationTool.fragments.dialogs.CreateCustomerDlg",
						type: "JS",
						controller: controller
					}).then(function (dialog) {
						controller._createCustomerDlg = dialog;
						controller.getView().addDependent(controller._createCustomerDlg);
						controller._createCustomerDlg.open();
					});
				} else {
					controller._createCustomerDlg.open();
				}
			},

			onCustomerCreateSearchVH: function (oEvent) {
				Models.setInitialCustomerSearchModel();
				if (controller.byId("bpRefTable")) {
					controller.byId("bpRefTable").removeSelections(true);
				}
				if (!controller._createSearchCustomerDlg) {
					Fragment.load({
						name: "ch.migrol.oi.PriceSimulationTool.fragments.dialogs.CreateSearchCustomerDlg",
						type: "JS",
						controller: controller
					}).then(function (dialog) {
						controller._createSearchCustomerDlg = dialog;
						controller.getView().addDependent(controller._createSearchCustomerDlg);
						controller._createSearchCustomerDlg.open();
					});
				} else {
					controller._createSearchCustomerDlg.open();
				}
			},

			onCancelDlg: function (oEvent) {
				oEvent.getSource().getParent().close();
			},

			onPriceSimRecordSelect: function (oEvent) {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var oPreisModel = this.getView().getModel("oPreisModel");
				oPreisModel.setProperty("/" + selectedTab + "View/itemSelected", true);

				var selectedItems = oEvent.getSource().getSelectedItems();
				var parameters = {};
				var i;
				var guid = null;
				guid = selectedItems[0].getBindingContext("preisResultModel").getProperty("IdResult");
				if (selectedItems.length >= 1) {
					$.each(selectedItems, function (key, val) {
						i = key + 1;
						parameters["P_MATNR" + i] = val.getBindingContext("preisResultModel").getProperty("MaterialNo");
					});
				}
				controller.telephoneSaleService.createPreisSimulationLink(guid, parameters);
				controller.toggleTelephoneSale();

				controller.collectiveOrderService.createCollectiveOrderLink(guid, parameters);
				controller.toggleCollectiveOrder();

				controller.contractCreationService.createContractCreationLink(guid, parameters);
				controller.toggleContractCreation();
			},

			onTelSale: function (oEvent) {
				var strLinkTelSaleTrans = controller.getModel("oPreisModel").getProperty("/s_LinkTelSaleTransGUID");
				sap.m.URLHelper.redirect(strLinkTelSaleTrans, true);
			},

			onCollectiveOrder: function (oEvent) {
				var strLinkColOrderTrans = controller.getModel("oPreisModel").getProperty("/s_LinkColOrderTransGUID");
				sap.m.URLHelper.redirect(strLinkColOrderTrans, true);
			},

			onContractCreation: function (oEvent) {
				var strLinkContrCreTrans = controller.getModel("oPreisModel").getProperty("/s_LinkContrCreTransGUID");
				sap.m.URLHelper.redirect(strLinkContrCreTrans, true);
			},

			toggleSaveData: function () {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				//use SoldToPartyName since it will determine that the sold to party is valid
				var isSoldToParty = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/SoldToParty").length > 0 ? true : false;

				var calculationData = controller.getModel("calculationModel").getData();
				if (Object.keys(calculationData).length === 0 || !isSoldToParty) {
					controller.getModel("oPreisModel").setProperty("/SaveDataEnabled", false);
				} else {
					if (!controller.getModel("oPreisModel").getProperty("/DataSaved"))
						controller.getModel("oPreisModel").setProperty("/SaveDataEnabled", true);
				}
			},

			toggleTelephoneSale: function () {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var itemSelected = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "View/itemSelected");
				var isSoldToParty = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/SoldToParty").length > 0 ? true : false;
				var isDataSaved = controller.getModel("oPreisModel").getProperty("/DataSaved");

				if (itemSelected && isDataSaved && isSoldToParty) {
					controller.getModel("oPreisModel").setProperty("/enableTelephoneSale", true);
				} else {
					controller.getModel("oPreisModel").setProperty("/enableTelephoneSale", false);
				}
			},

			toggleCollectiveOrder: function () {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var itemSelected = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "View/itemSelected");
				var isSoldToParty = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/SoldToParty").length > 0 ? true : false;
				var abteilung = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var isDataSaved = controller.getModel("oPreisModel").getProperty("/DataSaved");

				if (itemSelected && isDataSaved && isSoldToParty && (abteilung === "but")) {
					controller.getModel("oPreisModel").setProperty("/enableCollectiveOrder", true);
				} else {
					controller.getModel("oPreisModel").setProperty("/enableCollectiveOrder", false);
				}
			},

			toggleContractCreation: function () {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var itemSelected = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "View/itemSelected");
				var isSoldToParty = controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/SoldToParty").length > 0 ? true : false;
				var isDataSaved = controller.getModel("oPreisModel").getProperty("/DataSaved");

				if (itemSelected && isDataSaved && isSoldToParty) {
					controller.getModel("oPreisModel").setProperty("/enableContractCreation", true);
				} else {
					controller.getModel("oPreisModel").setProperty("/enableContractCreation", false);
				}
			},

			onChangeShipToPartyBuT: function (oEvent) {
				var path = oEvent.getSource().getBindingContext("shipToModel").getPath();
				var shipToParty = controller.getModel("shipToModel").getProperty(path + "/KunWe");

				if (shipToParty !== "") {
					controller.shipToPartyService.getShipToPartySet().done(function (oData) {
						$.each(oData.results, function (key, val) {
							if (shipToParty === val.ShipToParty) {
								controller.getModel("shipToModel").setProperty(path + "/KunWe", val.ShipToParty);
								controller.getModel("shipToModel").setProperty(path + "/KunWeName", val.ShipToPartyName);
								controller.getModel("shipToModel").setProperty(path + "/KunWeStreet", val.Shiptopartystreet);
								controller.getModel("shipToModel").setProperty(path + "/CustomerGroup", val.CustomerGroup);
								controller.getModel("shipToModel").setProperty(path + "/CustomerGroupName", val.CustomerGroupName);
								controller.getModel("shipToModel").setProperty(path + "/Ablad", 1);
							}
						});
					});
				} else {
					controller.getModel("shipToModel").setProperty(path + "/KunWe", "");
					controller.getModel("shipToModel").setProperty(path + "/KunWeName", "");
					controller.getModel("shipToModel").setProperty(path + "/KunWeStreet", "");
					controller.getModel("shipToModel").setProperty(path + "/CustomerGroup", "");
					controller.getModel("shipToModel").setProperty(path + "/CustomerGroupName", "");
				}

			},

			onChangeMaterial: function (materialNumber, material) {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");

				if (material !== "") {
					switch (materialNumber) {
					case "1":
						controller.getUnitOfMeasures(1);
						break;
					case "2":
						controller.getUnitOfMeasures(2);
						break;
					case "3":
						controller.getUnitOfMeasures(3);
						break;
					}
				}

				controller.materialService.getMaterialName(materialNumber, material).done(function (materialName) {
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/MaterialName" + materialNumber, materialName);
				});
			},

			onMatSelect: function (oEvent, material, property, matNo) {
				// var materialPath = matNo ? property + matNo : property;
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				// var mat = oEvent.getSource().getSelectedItem().getBindingContext("materialModel").getProperty(material);

				var mat1 = oEvent.getSource().getSelectedItem().getBindingContext("materialModel").getProperty("MaterialNo1");
				var mat2 = oEvent.getSource().getSelectedItem().getBindingContext("materialModel").getProperty("MaterialNo2");
				var mat3 = oEvent.getSource().getSelectedItem().getBindingContext("materialModel").getProperty("MaterialNo3");
				var desc1 = oEvent.getSource().getSelectedItem().getBindingContext("materialModel").getProperty("Description1");
				var desc2 = oEvent.getSource().getSelectedItem().getBindingContext("materialModel").getProperty("Description2");
				var desc3 = oEvent.getSource().getSelectedItem().getBindingContext("materialModel").getProperty("Description3");

				controller.getModel("oPreisModel").setProperty("/" + selectedTab + "/MaterialNumber1", mat1);
				controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/MaterialName1", desc1);
				controller.unitOfMeasureService.getUnitOfMeasures(1);
				if (selectedTab === "but") {
					controller.getModel("oPreisModel").setProperty("/but/AltMaterialNumber", mat2);
					controller.getModel("oPreisModel").setProperty("/butView/MaterialName2", desc2);
				} else if (selectedTab === "glb") {
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "/MaterialNumber2", mat2);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/MaterialName2", desc2);
					//	controller.unitOfMeasureService.getUnitOfMeasures(2);
				} else {
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "/MaterialNumber2", mat2);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "/MaterialNumber3", mat3);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/MaterialName2", desc2);
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/MaterialName3", desc3);

					controller.unitOfMeasureService.getUnitOfMeasures(2);
					controller.unitOfMeasureService.getUnitOfMeasures(3);
				}

				// controller.getModel("oPreisModel").setProperty("/" + selectedTab + materialPath, mat);
				controller.onCancelDlg(oEvent);
			},

			onKunnrSubmit: function (oEvent) {
				controller.organisationService.initializeSalesOrganisationService();
			},

			handleMaterialVH: function (oEvent, dialog, materialNumber) {
				var vhName = "_valueHelpDialog" + dialog;

				if (!controller[vhName]) {
					controller[vhName] = sap.ui.xmlfragment(
						"ch.migrol.oi.PriceSimulationTool.fragments.dialogs." + dialog,
						controller
					);
					controller.getView().addDependent(controller[vhName]);
				}

				controller.materialService.getMaterials(materialNumber).done(function (oData) {
					var materialModel = new sap.ui.model.json.JSONModel();
					materialModel.setSizeLimit(10000);
					materialModel.setData(oData.results);
					controller.getView().setModel(materialModel, "materialModel");
					controller[vhName].open();
				});
			},

			onChangeSalesOrg: function (oEvent) {
				var sValue = oEvent.getSource().getSelectedKey();
				controller.organisationService.setDistChanelData(sValue);
			},

			onChangeDistChan: function (oEvent) {
				controller.organisationService.setDivisionData();
			},

			onChangeDivision: function (oEvent) {
				controller.organisationService.setSalesOfficeData();
			},

			onChangeSalesOffice: function (oEvent) {
				var sSalesOfficeValue = oEvent.getSource().getSelectedKey();
				controller.organisationService.setSalesGroupData(sSalesOfficeValue);
			},

			onSaveData: function () {
				controller.getModel("oPreisModel").setProperty("/SaveDataEnabled", false);

				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				switch (selectedTab) {
				case "but":
					controller.byId("priceResultTableBuT").removeSelections();
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/itemSelected", false);
					controller.butService.save();
					controller.toggleTelephoneSale();
					controller.toggleCollectiveOrder();
					break;
				case "glb":
					controller.byId("priceResultTableGLB").removeSelections();
					controller.getModel("oPreisModel").setProperty("/" + selectedTab + "View/itemSelected", false);
					controller.glbService.save();
					controller.toggleContractCreation();
					controller.toggleTelephoneSale();
					break;
				case "sua":
					controller.byId("priceResultTableSuA").removeSelections();
					controller.suaService.save().done(function (oData) {
						var parameters = {};
						var i;
						var guid = null;
						guid = oData.results[0].IdResult;
						if (oData.results.length >= 1) {
							$.each(oData.results, function (key, val) {
								i = key + 1;
								parameters["P_MATNR" + i] = val.MaterialNo;
							});
						}
						controller.telephoneSaleService.createPreisSimulationLink(guid, parameters);
						controller.toggleTelephoneSale();
					});
					break;
				default:
					break;
				}
			},

			onCalculateBuT: function (oEvent) {
				controller.byId("priceResultTableBuT").removeSelections();
				var mandatoryCheck = controller.butService.checkMandatoryFields();
				if (mandatoryCheck) {
					controller.butService.calculate();
				}
				controller.getModel("oPreisModel").setProperty("/enableTelephoneSale", false);
				controller.getModel("oPreisModel").setProperty("/enableCollectiveOrder", false);

				controller.getModel("oPreisModel").setProperty("/DataSaved", false);
			},

			onCalculateSuA: function (oEvent) {
				controller.byId("priceResultTableSuA").removeSelections();
				var mandatoryCheck = controller.suaService.checkMandatoryFields();

				if (mandatoryCheck) {
					controller.suaService.calculate();
				}
				controller.getModel("oPreisModel").setProperty("/enableTelephoneSale", false);

				controller.getModel("oPreisModel").setProperty("/DataSaved", false);
			},

			onCalculateGlb: function (oEvent) {
				controller.byId("priceResultTableGLB").removeSelections();
				var mandatoryCheck = controller.glbService.checkMandatoryFields();

				if (mandatoryCheck) {
					controller.glbService.calculate();
				}
				controller.getModel("oPreisModel").setProperty("/enableContractCreation", false);
				controller.getModel("oPreisModel").setProperty("/enableTelephoneSale", false);

				controller.getModel("oPreisModel").setProperty("/DataSaved", false);
			},

			onChangePreisModel: function () {
				controller.getModel("oPreisModel").detachEvent("propertyChange", controller.onChangePreisModel, controller);
				controller.getModel("oPreisModel").setProperty("/SaveDataEnabled", false);
				controller.getModel("oPreisModel").setProperty("/DataSaved", false);
			},

			onCustomerResultSelect: function (oEv) {
				controller.getModel("customerSearchModel").setProperty("/viewData/submitButtonEnabled", true);
			},

			onCreateCustomerSearch: function (oEvent) {
				controller.businessPartnerSearchService.getBusinessPartners().done(function (oData) {
					Fragment.load({
						name: "ch.migrol.oi.PriceSimulationTool.fragments.tables.CreateCustomerTableCells",
						type: "JS",
						controller: controller
					}).then(function (template) {
						controller.getView().addDependent(controller.template);
						controller.byId("createCustomerTable").bindItems("customerSearchModel>/results/", template);
					});
					controller.getModel("customerSearchModel").setProperty("/viewData/bpRefExpanded", false);
				});
			},

			onCreateCustomerSubmit: function (oEvent) {
				var selectedItem = controller.byId("createCustomerTable").getSelectedItem();
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var preisModel = controller.getModel("oPreisModel");
				if (selectedItem) {
					var partnerNo = selectedItem.getBindingContext("customerSearchModel").getProperty("Partner");
					var partnerName = selectedItem.getBindingContext("customerSearchModel").getProperty("FullName");

					preisModel.setProperty("/" + selectedTab + "/SoldToParty", partnerNo);
					preisModel.setProperty("/" + selectedTab + "View/SoldToPartyName", partnerName);
					preisModel.setProperty("/" + selectedTab + "Mandatory/PostalCode", false);
					preisModel.setProperty("/" + selectedTab + "View/SoldToPartyEnabled", true);

					//if (preisModel.getProperty("/" + selectedTab + "/PostalCode") === "") {
					preisModel.setProperty("/" + selectedTab + "View/PostalCodeEnabled", false);
					preisModel.setProperty("/CustomerCreationEnabled", false);
					//}
				}
				controller.onCancelDlg(oEvent);
				controller.organisationService.initializeSalesOrganisationService();
				controller.autoGetShipToParty();
				controller.toggleSaveData();
				controller.setCalculationDataSoldToParty();
			},

			onCreateCustomer: function (oEvent) {
				var dialog = oEvent.getSource();
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var preisModel = controller.getModel("oPreisModel");
				controller.businessPartnerCreateService.createCustomer().done(function (data) {
					var partner = data.Partner;
					var postalCode = data.PostalCode;
					if (partner !== "") {
						var partnerName = data.NameFirst + " " + data.NameLast;
						preisModel.setProperty("/" + selectedTab + "/SoldToParty", partner);
						preisModel.setProperty("/" + selectedTab + "View/SoldToPartyName", partnerName);
						preisModel.setProperty("/" + selectedTab + "View/SoldToPartyEnabled", true);

						preisModel.setProperty("/" + selectedTab + "/PostalCode", postalCode);

						preisModel.setProperty("/" + selectedTab + "View/PostalCodeEnabled", false);
						preisModel.setProperty("/" + selectedTab + "Mandatory/PostalCode", false);
						preisModel.setProperty("/CustomerCreationEnabled", false);

						dialog.getParent().close();
						controller.organisationService.initializeSalesOrganisationService();
						controller.autoGetShipToParty();
						controller.toggleSaveData();
						controller.setCalculationDataSoldToParty();
					} else {
						MessageBox.error(controller.getResourceBundle().getText("errorCustomerCreation"));
					}
				});
			},

			onPLZKunnrLiveChange: function (value, property, oppositeProperty) {
				var preisModel = controller.getView().getModel("oPreisModel");
				var selectedTab = preisModel.getProperty("/selectedTab");
				var oppositeValue = preisModel.getProperty(oppositeProperty);
				if (value === "") {
					preisModel.setProperty(property, true);
				}
				if (value !== "" && oppositeValue === "") {
					preisModel.setProperty(property, false);
				}
				if (value !== "" && property === "/" + selectedTab + "View/PostalCodeEnabled") {
					preisModel.setProperty("/CustomerCreationEnabled", false);
				}
				if (value === "" && property === "/" + selectedTab + "View/PostalCodeEnabled") {
					preisModel.setProperty("/CustomerCreationEnabled", true);
				}
			},

			onMessagesButtonPress: function (oEvent) {
				var oMessagesButton = oEvent.getSource();
				if (!this._messagePopover) {
					this._messagePopover = new sap.m.MessagePopover({
						items: {
							path: "message>/",
							template: new sap.m.MessagePopoverItem({
								description: "{message>description}",
								type: "{message>type}",
								title: "{message>message}"
							})
						}
					});
					oMessagesButton.addDependent(this._messagePopover);
				}
				this._messagePopover.toggle(oMessagesButton);
			},

			onBPRefSelect: function (oEvent) {
				var bindingContext = oEvent.getSource().getSelectedItem().getBindingContext("BPRefModel");
				var customerSearchModel = controller.getModel("customerSearchModel");
				customerSearchModel.setProperty("/viewData/createButtonEnabled", true);
				customerSearchModel.setProperty("/selectedBPRef/AccountGroup", bindingContext.getProperty("AccountGroup"));
				customerSearchModel.setProperty("/selectedBPRef/CustomerGroup", bindingContext.getProperty("CustomerGroup"));
				customerSearchModel.setProperty("/selectedBPRef/SalesOrganisation", bindingContext.getProperty("SalesOrganisation"));
				customerSearchModel.setProperty("/selectedBPRef/DistributionChannel", bindingContext.getProperty("DistributionChannel"));
				customerSearchModel.setProperty("/selectedBPRef/Division", bindingContext.getProperty("Division"));
				customerSearchModel.setProperty("/selectedBPRef/SalesDistrict", bindingContext.getProperty("SalesDistrict"));
				customerSearchModel.setProperty("/selectedBPRef/BusinessPartnerRef", bindingContext.getProperty("BusinessPartnerRef"));
			},

			onEquipmentVH: function (oEvent) {
				controller.equipmentService.getEquipmentSet().done(function (oData) {
					Fragment.load({
						name: "ch.migrol.oi.PriceSimulationTool.fragments.dialogs.EquipmentDlg",
						type: "XML",
						controller: controller
					}).then(function (dialog) {
						controller.equipmentDlg = dialog;
						controller.getView().addDependent(controller.equipmentDlg);
						controller.equipmentDlg.open();
					});
				});
			},

			onEquipDetailsChange: function (oEvent) {
				controller.emptyEquipmentNumber();
				var equipment = controller.getModel("oPreisModel").getProperty("/sua/Equipment");
				var equipmentCategory = controller.getModel("oPreisModel").getProperty("/sua/EquipCategory");

				if (equipment === "") {
					controller.equipmentService.getEquipmentSize().done(function (oData) {
						var equipmentDescription;
						switch (equipmentCategory) {
						case "T":
							controller.getModel("oPreisModel").setProperty("/sua/TankSize", oData.TankSize);
							controller.tankSizeService.getTankSizeSet().done(function (oDataSizeT) {
								var tankSize = controller.getModel("oPreisModel").getProperty("/sua/TankSize");
								var itemLine = oDataSizeT.filter(function (el) {
									return el.Key === tankSize;
								});
								controller.getModel("oPreisModel").setProperty("/suaView/EquipmentSizeDescr", itemLine["0"].Name);

							});
							break;
						case "C":
							controller.getModel("oPreisModel").setProperty("/sua/BoilerSize", oData.BoilerSize);
							controller.boilerSizeService.getBoilerSizeSet().done(function (oDataSizeC) {
								var boilerSize = controller.getModel("oPreisModel").getProperty("/sua/BoilerSize");
								var itemLine = oDataSizeC.filter(function (el) {
									return el.Key === boilerSize;
								});
								controller.getModel("oPreisModel").setProperty("/suaView/EquipmentSizeDescr", itemLine["0"].Name);

							});

							controller.getModel("oPreisModel").setProperty("/suaView/EquipmentSizeDescr", equipmentDescription);
							break;
						}
					});
				}
			},

			emptyEquipmentNumber: function () {
				controller.getModel("oPreisModel").setProperty("/sua/Equipment", "");
			},

			onTankSizeVH: function (oEvent) {
				controller.tankSizeService.getTankSizeSet().done(function (oData) {
					Fragment.load({
						name: "ch.migrol.oi.PriceSimulationTool.fragments.dialogs.TankSizeDlg",
						type: "XML",
						controller: controller
					}).then(function (dialog) {
						controller.tankSizeDlg = dialog;
						controller.getView().addDependent(controller.tankSizeDlg);
						controller.tankSizeDlg.open();
					});
				});

			},

			onBoilerSizeVH: function (oEvent) {
				controller.boilerSizeService.getBoilerSizeSet().done(function (oData) {
					Fragment.load({
						name: "ch.migrol.oi.PriceSimulationTool.fragments.dialogs.BoilerSizeDlg",
						type: "XML",
						controller: controller
					}).then(function (dialog) {
						controller.boilerSizeDlg = dialog;
						controller.getView().addDependent(controller.boilerSizeDlg);
						controller.boilerSizeDlg.open();
					});
				});

			},

			onEquipmentSelect: function (oEvent) {
				var bindingContext = oEvent.getSource().getSelectedItem().getBindingContext("equipmentModel");
				var oPreisModel = controller.getModel("oPreisModel");
				var selectedTab = oPreisModel.getProperty("/selectedTab");

				oPreisModel.setProperty("/" + selectedTab + "/Equipment", bindingContext.getProperty("Equipment"));
				oPreisModel.setProperty("/" + selectedTab + "/EquipCategory", bindingContext.getProperty("EquipCategory"));
				oPreisModel.setProperty("/" + selectedTab + "/BoilerVolume", parseInt(bindingContext.getProperty("BoilerVolume"), 10) + "");
				oPreisModel.setProperty("/" + selectedTab + "/BoilerSize", bindingContext.getProperty("BoilerSize"));
				oPreisModel.setProperty("/" + selectedTab + "/VolumeUnit", parseInt(bindingContext.getProperty("VolumeUnit"), 10) + "");
				oPreisModel.setProperty("/" + selectedTab + "/VolumeTotal", parseInt(bindingContext.getProperty("VolumeTotal"), 10) + "");
				oPreisModel.setProperty("/" + selectedTab + "/TankCount", parseInt(bindingContext.getProperty("TankCount"), 10) + "");
				oPreisModel.setProperty("/" + selectedTab + "/Lagergut", bindingContext.getProperty("Lagergut"));
				oPreisModel.setProperty("/" + selectedTab + "/TankSize", bindingContext.getProperty("TankSize"));
				controller.onCancelDlg(oEvent);
			},

			onCreateEquipment: function () {
				var mandatoryCheck = controller.equipmentService.checkMandatoryFields();
				if (mandatoryCheck) {
					controller.equipmentService.createEquipment().done(function (data) {
						controller.getModel("oPreisModel").setProperty("/sua/Equipment", data.Equipment);
						var equipmentCreateMessage = controller.getResourceBundle().getText("equipmentCreateMessage");
						MessageToast.show(equipmentCreateMessage);
					});
				}
			},

			onTankSizeSelect: function (oEvent) {
				var bindingContext = oEvent.getSource().getSelectedItem().getBindingContext("tankSizeModel");
				var oPreisModel = controller.getModel("oPreisModel");
				var selectedTab = oPreisModel.getProperty("/selectedTab");
				oPreisModel.setProperty("/" + selectedTab + "/TankSize", bindingContext.getProperty("Key"));
				oPreisModel.setProperty("/" + selectedTab + "View/EquipmentSizeDescr", bindingContext.getProperty("Name"));
				controller.onEquipDetailsChange();
				controller.onCancelDlg(oEvent);
			},

			onBoilerSizeSelect: function (oEvent) {
				var bindingContext = oEvent.getSource().getSelectedItem().getBindingContext("boilerSizeModel");
				var oPreisModel = controller.getModel("oPreisModel");
				var selectedTab = oPreisModel.getProperty("/selectedTab");
				oPreisModel.setProperty("/" + selectedTab + "/BoilerSize", bindingContext.getProperty("Key"));
				oPreisModel.setProperty("/" + selectedTab + "View/EquipmentSizeDescr", bindingContext.getProperty("Name"));

				controller.onEquipDetailsChange();
				controller.onCancelDlg(oEvent);

			},

			onSelectTermingeschaeft: function (oEvent) {
				var selected = oEvent.getSource().getSelected();
				var preisModel = controller.getModel("oPreisModel");
				var selectedTab = preisModel.getProperty("/selectedTab");

				if (selected && selectedTab !== "sua") {
					preisModel.setProperty("/" + selectedTab + "Mandatory/DeliveryDateFrom", false);
					preisModel.setProperty("/" + selectedTab + "Mandatory/DeliveryDateTo", false);
					preisModel.setProperty("/" + selectedTab + "Mandatory/AltDeliveryDateFrom", true);
					preisModel.setProperty("/" + selectedTab + "Mandatory/AltDeliveryDateTo", true);
				} else {
					preisModel.setProperty("/" + selectedTab + "Mandatory/DeliveryDateFrom", true);
					preisModel.setProperty("/" + selectedTab + "Mandatory/DeliveryDateTo", true);
					preisModel.setProperty("/" + selectedTab + "Mandatory/AltDeliveryDateFrom", false);
					preisModel.setProperty("/" + selectedTab + "Mandatory/AltDeliveryDateTo", false);
				}
			},

			onDeliveryDateChange: function () {
				var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
				var preisModel = controller.getModel("oPreisModel");
				var deliveryDatePromtFrom = preisModel.getProperty("/" + selectedTab + "/DeliveryDateFrom");
				var deliveryDatePromtTo = preisModel.getProperty("/" + selectedTab + "/DeliveryDateTo");
				var deliveryDateAltFrom = preisModel.getProperty("/" + selectedTab + "/AltDeliveryDateFrom");
				var deliveryDateAltTo = preisModel.getProperty("/" + selectedTab + "/AltDeliveryDateTo");

				var promtMandatory = true;
				var altMandatory = false;

				if (deliveryDatePromtFrom !== "" || deliveryDatePromtTo !== "") {
					promtMandatory = true;
				} else if (deliveryDateAltFrom !== "" || deliveryDateAltTo !== "") {
					promtMandatory = false;
					altMandatory = true;
				}
				if (deliveryDateAltFrom !== "" || deliveryDateAltTo !== "") {
					altMandatory = true;
				}

				preisModel.setProperty("/" + selectedTab + "Mandatory/DeliveryDateFrom", promtMandatory);
				preisModel.setProperty("/" + selectedTab + "Mandatory/DeliveryDateTo", promtMandatory);
				preisModel.setProperty("/" + selectedTab + "Mandatory/AltDeliveryDateFrom", altMandatory);
				preisModel.setProperty("/" + selectedTab + "Mandatory/AltDeliveryDateTo", altMandatory);
			},

			onShipToPartyPostalCodeChange: function (oEvent) {
				var path = oEvent.getSource().getBindingContext("shipToModel").getPath();
				var postalCode = controller.getModel("shipToModel").getProperty(path + "/PLZ");
				var shipToParty = controller.getModel("shipToModel").getProperty(path + "/ShipToParty");

				if (postalCode !== "") {
					controller.postalCodeService.getPostalCode(postalCode, shipToParty).done(function (oData) {
						controller.getModel("shipToModel").setProperty(path + "/ShipToPartyCity", oData.ShipToPartyCity);
					}).fail(function () {
						controller.getModel("shipToModel").setProperty(path + "/ShipToPartyCity", "");
					});
				} else {
					controller.getModel("shipToModel").setProperty(path + "/ShipToPartyCity", "");
				}
			},

			onGlobalPostalCodeChange: function (oEvent) {
				var path = oEvent.getSource().getBindingContext("postalCodeModel").getPath();
				var postalCode = controller.getModel("postalCodeModel").getProperty(path + "/PostalCode");
				var shipToParty = "";

				if (postalCode !== "") {
					controller.postalCodeService.getPostalCode(postalCode, shipToParty).done(function (oData) {
						controller.getModel("postalCodeModel").setProperty(path + "/PostalCodeCity", oData.ShipToPartyCity);
					}).fail(function () {
						controller.getModel("postalCodeModel").setProperty(path + "/PostalCodeCity", "");
					});
				} else {
					controller.getModel("postalCodeModel").setProperty(path + "/PostalCodeCity", "");
				}
			},

			setCalculationDataSoldToParty: function () {
				var calculationModel = controller.getModel("calculationModel");
				if (Object.keys(calculationModel).length !== 0) {
					var selectedTab = controller.getModel("oPreisModel").getProperty("/selectedTab");
					var oPreisModel = controller.getModel("oPreisModel");
					var soldToParty = oPreisModel.getProperty("/" + selectedTab + "/SoldToParty");
					var salesOffice = oPreisModel.getProperty("/general/SalesOffice");
					var salesGroup = oPreisModel.getProperty("/general/SalesGroup");

					calculationModel.setProperty("/SoldToParty", soldToParty);
					calculationModel.setProperty("/SalesOffice", salesOffice);
					calculationModel.setProperty("/SalesGroup", salesGroup);
				}
			},

			onAddressDataSuggestionVH: function (oEvent) {
				var bModel = this.getView().getModel("customerSearchModel");
				var addressModel = this.getView().getModel("addressSuggestionSearchModel");
				
				//var bData = bModel.getData();
				var addressData = addressModel.getData();
				
				if (addressData.parameters.Percent) {

					this.getAddressDataSuggestions();

					if (!controller._addressSuggestionDlg) {
						Fragment.load({
							name: "ch.migrol.oi.PriceSimulationTool.fragments.dialogs.AddressDataSuggestionsDlg",
							controller: this
						}).then(function (dialog) {
							controller._addressSuggestionDlg = dialog;
							controller.getView().addDependent(controller._addressSuggestionDlg);
							controller._addressSuggestionDlg.open();
						});
					} else {
						controller._addressSuggestionDlg.open();
					}
				}

			},
			getAddressDataSuggestions: function () {
				var bModel = this.getView().getModel("customerSearchModel");
				var addressModel = this.getView().getModel("addressSuggestionSearchModel");

				var bData = bModel.getData();
				var addressData = addressModel.getData();

				var oCountry = 'CH'; // This is constant as Switzerland
				var oCity = bData.parameters.City;
				/*var oRegion = bData.parameters.Region;*/
				var oRegion = "";
				var oPostCode1 = bData.parameters.PostalCode;
				var oStreet = bData.parameters.Street;
				var oHouseNum1 = bData.parameters.HouseNo;
				var oPercent = addressData.parameters.Percent;

				sap.ui.core.BusyIndicator.show(0);
				var oModel = this.getView().getModel();
				oModel.setUseBatch(false);
				var mParameters = {
					urlParameters: {
						"$expand": "AddresToSuggestions"
					},
					success: function (oData) {
						var addressSuggestions = oData;
						var oAttachmentsModelNote = new sap.ui.model.json.JSONModel(addressSuggestions);
						this.getView().setModel(oAttachmentsModelNote, "AddressSuggestions");
					}.bind(this),
					error: function (oError) {
						this.getView().setModel(new sap.ui.model.json.JSONModel( ), "AddressSuggestions");
						jQuery.sap.log.info("Odata Error occured");
					}.bind(this)
				};
				var path =
					"/AddressSuggestionSet(Percent='" + oPercent + "',Country='" + oCountry +
					"',Region='" + oRegion + "',PostCode1='" + oPostCode1 + "',City1='" + oCity + "',Street='" + oStreet + "',HouseNum1='" +
					oHouseNum1 +
					"')";
				oModel.read(path, mParameters);
				sap.ui.core.BusyIndicator.hide();
			},
			onOkAddressSuggestionDlg: function (oEvent) {
				var oModel = this.getView().getModel("AddressSuggestions");
				var oData = oModel.getData();

				var bModel = this.getView().getModel("customerSearchModel");
				var bData = bModel.getData();

				var contextPath = controller._addressSuggestionDlg.getContent()[1].getSelectedContextPaths()[0];
				if (!contextPath) {
					var oBundle = this.getView().getModel("i18n").getResourceBundle();
					var popupMessage = oBundle.getText("AddressDataSuggestionsDlgSelectOneLine");
					MessageBox.error(popupMessage);
					return;
				}
				var index = contextPath.split('/results/')[1];

				var getSelectedLine = oData.AddresToSuggestions.results[index];

				bData.parameters.City = getSelectedLine.City1;
				bData.parameters.Region = getSelectedLine.Region;
				bData.parameters.PostalCode = getSelectedLine.PostCode1;
				bData.parameters.Street = getSelectedLine.Street;
				bData.parameters.HouseNo = getSelectedLine.HouseNum1;

				bModel.setData(bData);

				oEvent.getSource().getParent().close();
			}

		});
	});