sap.ui.define([
		"sap/ui/layout/form/Form",
		"sap/ui/layout/form/FormContainer",
		"sap/ui/layout/form/FormElement",
		"sap/m/Input",
		"sap/m/Label",
		"sap/m/Column",
		"sap/m/ColumnListItem",
		"sap/m/Select"
	],
	function (
		Form,
		FormContainer,
		FormElement,
		Input,
		Label,
		Column,
		ColumnListItem,
		Select
	) {
		"use strict";

		sap.ui.jsfragment("ch.migrol.oi.PriceSimulationTool.fragments.dialogs.CreateSearchCustomerDlg", {
			createContent: function (oController) {

				var createCustomerDialog = new sap.m.Dialog({
					stretch: true,
					title: "{i18n>fastCreateCustomer}",
					content: [
						new sap.m.VBox({
							items: [
								new Form({
									editable: true,
									layout: new sap.ui.layout.form.ResponsiveGridLayout(),
									formContainers: [new FormContainer({
										title: "{i18n>CustomerCreateDlgKundendatenTitle}",
										formElements: [
											new FormElement({
												label: "{i18n>CustomerCreateDlgTitleLangLabel}",
												fields: [
													new Select({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/Title} || ${businessPartnerCreateMandatoryModel>/Title} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/Title} === '' ? 'Error' : 'None'}",
														selectedKey: "{customerSearchModel>/parameters/Title}",
														items: {
															path: "customerTitleModel>/results",
															template: new sap.ui.core.Item({
																key: "{customerTitleModel>Key}",
																text: "{customerTitleModel>Name}"
															})
														}
													}),
													new Select({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/Language} || ${businessPartnerCreateMandatoryModel>/Language} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/Language} === '' ? 'Error' : 'None'}",
														// placeholder: "{i18n>CustomerCreateDlgLanguageLabel}",
														selectedKey: "{customerSearchModel>/parameters/Language}",
														items: [
															new sap.ui.core.Item({
																key: "",
																text: ""
															}),
															new sap.ui.core.Item({
																key: "de",
																text: "{i18n>germanyLang}"
															}),
															new sap.ui.core.Item({
																key: "it",
																text: "{i18n>italyLang}"
															}),
															new sap.ui.core.Item({
																key: "fr",
																text: "{i18n>franceLang}"
															})
														]
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgFirstLastNameLabel}",
												fields: [
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/NameFirst} || ${businessPartnerCreateMandatoryModel>/NameFrist} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/NameFirst} === '' ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgVornameLabel}",
														value: "{customerSearchModel>/parameters/NameFirst}",
														submit: [oController.onCreateCustomerSearch, oController]
													}),
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/NameLast} || ${businessPartnerCreateMandatoryModel>/NameLast} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/NameLast} === ''  ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgNachnameLabel}",
														value: "{customerSearchModel>/parameters/NameLast}",
														submit: [oController.onCreateCustomerSearch, oController]
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgSuchbegriffLabel}",
												fields: [
													new Input({
														placeholder: "{i18n>CustomerCreateDlgSuchbegriffLabel}",
														value: "{customerSearchModel>/parameters/SearchTerm}"
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgStrasseNummerLabel}",
												fields: [
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/Street} || ${businessPartnerCreateMandatoryModel>/Street} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/Street} === '' ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgStrasseLabel}",
														value: "{customerSearchModel>/parameters/Street}",
														submit: [oController.onCreateCustomerSearch, oController]
													}),
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/HouseNo} || ${businessPartnerCreateMandatoryModel>/HouseNo} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/HouseNo} === '' ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgNummerLabel}",
														value: "{customerSearchModel>/parameters/HouseNo}",
														submit: [oController.onCreateCustomerSearch, oController]
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgLandPLZLabel}",
												fields: [
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/Country} || ${businessPartnerCreateMandatoryModel>/Country} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/Country} === '' ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgLandLabel}",
														// value: "{customerSearchModel>/parameters/Country}",
														value: "{i18n>countrySwiss}",
														enabled: false,
														submit: [oController.onCreateCustomerSearch, oController]
													}),
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/PostalCode} || ${businessPartnerCreateMandatoryModel>/PostalCode} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/PostalCode} === '' ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgPLZLabel}",
														value: "{customerSearchModel>/parameters/PostalCode}",
														submit: [oController.onCreateCustomerSearch, oController]
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgOrtLabel}",
												fields: [
													/*	new Input({
															valueState: "{= ${businessPartnerSearchRuleModel>/Region} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
															placeholder: "{i18n>CustomerCreateDlgRegionLabel}",
															value: "{customerSearchModel>/parameters/Region}",
															submit: [oController.onCreateCustomerSearch, oController]
														}), */
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/City} || ${businessPartnerCreateMandatoryModel>/City} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/City} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgOrtLabel}",
														value: "{customerSearchModel>/parameters/City}",
														submit: [oController.onCreateCustomerSearch, oController]
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgTelefon1Telefon2Label}",
												fields: [
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/Telephone1} || ${businessPartnerCreateMandatoryModel>/Telephone1} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/Telephone1} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgTelefon1Label}",
														value: "{customerSearchModel>/parameters/Telephone1}",
														submit: [oController.onCreateCustomerSearch, oController]
													}),
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/Telephone2} || ${businessPartnerCreateMandatoryModel>/Telephone2} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/Telephone2} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgTelefon2Label}",
														value: "{customerSearchModel>/parameters/Telephone2}",
														submit: [oController.onCreateCustomerSearch, oController]
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgEmailLabel}",
												fields: [
													new Input({
														valueState: "{= ( ${businessPartnerSearchRuleModel>/Email} || ${businessPartnerCreateMandatoryModel>/Email} ) && ${customerSearchModel>/viewData/showValidation} && ${customerSearchModel>/parameters/Email} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgEmailLabel}",
														value: "{customerSearchModel>/parameters/Email}",
														submit: [oController.onCreateCustomerSearch, oController]
													})
												]
											}),
											new FormElement({
												label: "{i18n>MatchPercentage}",
												fields: [
													new Input("percent", {
														//valueState: "{= ( ${customerSearchModel>/parameters/Percent} === '' ? 'Error' : 'None' )}",
														valueState: "{= ( ${addressSuggestionSearchModel>/parameters/Percent} === '' ? 'Error' : 'None' )}",
														placeholder: "{i18n>MatchPercentage}",
														type: sap.m.InputType.Number,
														//	value: "{customerSearchModel>/parameters/Percent}",
														value: "{addressSuggestionSearchModel>/parameters/Percent}",
														submit: [oController.onSuggestionCustomers, oController]
													}),
													new sap.m.Button({
														text: "{i18n>CheckAddressDetails}",
														width: "50%",
														press: [oController.onAddressDataSuggestionVH, oController]
													}),
													new sap.m.Button({
														layoutData: new sap.ui.layout.GridData({
															span: "L2 M2 S4",
															indentXL: 10,
															indentL: 10,
															indentM: 10,
															indentS: 8
														}),
														text: "{i18n>CustomerCreateSubmitBtn}",
														press: [oController.onCreateCustomerSearch, oController]
													})
												]
											})
										]
									})]
								}),
								new sap.m.Panel({
									headerText: "{i18n>BPRefTableHead}",
									expandable: true,
									expanded: "{customerSearchModel>/viewData/bpRefExpanded}",
									content: new sap.m.Table(oController.createId("bpRefTable"), {
										mode: sap.m.ListMode.SingleSelectMaster,
										selectionChange: [oController.onBPRefSelect, oController],
										columns: [
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefGroup}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefCGroup}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefSOrg}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefDChl}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefDv}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefPartner}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefDescription}"
												})
											})
										],
										items: {
											path: "BPRefModel>/",
											template: new ColumnListItem({
												cells: [
													new sap.m.Text({
														text: "{BPRefModel>AccountGroup}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>CustomerGroup}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>SalesOrganisation}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>DistributionChannel}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>Division}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>BusinessPartnerRef}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>Description}"
													})
												]
											})
										}
									})
								}),
								new sap.m.Panel({
									headerText: "{i18n>CustomerCreateResultHead}",
									content: new sap.m.ScrollContainer({
										vertical: true,
										content: new sap.m.Table(oController.createId("createCustomerTable"), {
											width: "2000px",
											selectionChange: [oController.onCustomerResultSelect, oController],
											mode: sap.m.ListMode.SingleSelectMaster,
											columns: [
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreatePartnerCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateTitelCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateFullNameCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreatePLZCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateRegionCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateLandCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateOrtCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateStrasseCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateNummerCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateKreisCol}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateTelefon1Col}"
													})
												}),
												new Column({
													header: new sap.m.Text({
														text: "{i18n>CustomerCreateTelefon2Col}"
													})
												})
											]
										})
									})
								})
							]
						})
					],
					buttons: [
						new sap.m.Button({
							text: "{i18n>confirm}",
							press: [oController.onCreateCustomerSubmit, oController],
							enabled: "{customerSearchModel>/viewData/submitButtonEnabled}"
						}),
						new sap.m.Button({
							text: "{i18n>createCustomer}",
							press: [oController.onCreateCustomer, oController],
							enabled: "{customerSearchModel>/viewData/createButtonEnabled}"
						}), new sap.m.Button({
							press: [oController.onCancelDlg, oController],
							text: "{i18n>reset}"
						})
					]
				});

				return createCustomerDialog;
			}
		});
	});