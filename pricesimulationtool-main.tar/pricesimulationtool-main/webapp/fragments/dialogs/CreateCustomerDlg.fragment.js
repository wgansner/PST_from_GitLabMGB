sap.ui.define([
		"sap/ui/layout/form/Form",
		"sap/ui/layout/form/FormContainer",
		"sap/ui/layout/form/FormElement",
		"sap/m/Input",
		"sap/m/Label",
		"sap/m/Column",
		"sap/m/ColumnListItem",
		"sap/m/Select"
	],
	function (
		Form,
		FormContainer,
		FormElement,
		Input,
		Label,
		Column,
		ColumnListItem,
		Select
	) {
		"use strict";
		
		/**
		 * IMPORTANT: Do not use this anymore, unless you need a Dialog for only creating a Customer and not searching.
		 * 
		 */

		sap.ui.jsfragment("ch.migrol.oi.PriceSimulationTool.fragments.dialogs.CreateCustomerDlg", {
			createContent: function (oController) {

				var createCustomerDialog = new sap.m.Dialog({
					stretch: true,
					title: "{i18n>fastCreateCustomer}",
					content: [
						new sap.m.VBox({
							items: [
								new Form({
									editable: true,
									layout: new sap.ui.layout.form.ResponsiveGridLayout(),
									formContainers: [new FormContainer({
										title: "{i18n>CustomerCreateDlgKundendatenTitle}",
										formElements: [
											new FormElement({
												label: "{i18n>CustomerCreateDlgTitleLangLabel}",
												fields: [
													new Select({
														valueState: "{= ${businessPartnerSearchRuleModel>/Title} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														selectedKey: "{customerSearchModel>/parameters/Title}",
														items: {
															path: "customerTitleModel>/results",
															template: new sap.ui.core.Item({
																key: "{customerTitleModel>Key}",
																text: "{customerTitleModel>Name}"
															})
														}
													}),
													new Select({
														valueState: "{= ${businessPartnerSearchRuleModel>/Language} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														selectedKey: "{customerSearchModel>/parameters/Language}",
														items:[
															new sap.ui.core.Item({
																key: "",
																text: ""
															}),
															new sap.ui.core.Item({
																key: "de",
																text: "{i18n>germanyLang}"
															}),
															new sap.ui.core.Item({
																key: "it",
																text: "{i18n>italyLang}"
															}),
															new sap.ui.core.Item({
																key: "fr",
																text: "{i18n>franceLang}"
															})	
														]
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgFirstLastNameLabel}",
												fields: [
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/NameFirst} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgVornameLabel}",
														value: "{customerSearchModel>/parameters/NameFirst}"
													}),
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/NameLast} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgNachnameLabel}",
														value: "{customerSearchModel>/parameters/NameLast}"
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgSuchbegriffLabel}",
												fields: [
													new Input({
														placeholder: "{i18n>CustomerCreateDlgSuchbegriffLabel}",
														value: "{customerSearchModel>/parameters/SearchTerm}"
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgStrasseNummerLabel}",
												fields: [
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/Street} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgStrasseLabel}",
														value: "{customerSearchModel>/parameters/Street}"
													}),
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/HouseNo} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgNummerLabel}",
														value: "{customerSearchModel>/parameters/HouseNo}"
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgLandPLZOrtLabel}",
												fields: [
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/Country} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgLandLabel}",
														value: "{i18n>countrySwiss}",
														enabled: false
													}),
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/PostalCode} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgPLZLabel}",
														value: "{customerSearchModel>/parameters/PostalCode}"
													}),
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/City} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgOrtLabel}",
														value: "{customerSearchModel>/parameters/City}"
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgRegionKreisLabel}",
												fields: [
												/*	new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/Region} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgRegionLabel}",
														value: "{customerSearchModel>/parameters/Region}"
													}), */
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/District} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgKreisLabel}",
														value: "{customerSearchModel>/parameters/District}"
													})
												]
											}), 
											new FormElement({
												label: "{i18n>CustomerCreateDlgTelefon1Telefon2Label}",
												fields: [
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/Telephone1} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgTelefon1Label}",
														value: "{customerSearchModel>/parameters/Telephone1}"
													}),
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/Telephone2} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgTelefon2Label}",
														value: "{customerSearchModel>/parameters/Telephone2}"
													})
												]
											}),
											new FormElement({
												label: "{i18n>CustomerCreateDlgEmailLabel}",
												fields: [
													new Input({
														valueState: "{= ${businessPartnerSearchRuleModel>/Email} && ${customerSearchModel>/viewData/showValidation} ? 'Error' : 'None'}",
														placeholder: "{i18n>CustomerCreateDlgEmailLabel}",
														value: "{customerSearchModel>/parameters/Email}"
													})
												]
											})
										]
									})]
								}),
								new sap.m.Panel({
									headerText: "{i18n>BPRefTableHead}",
									expandable: true,
									expanded: "{customerSearchModel>/viewData/bpRefExpanded}",
									content: new sap.m.Table(oController.createId("bpRefSearchTable"), {
										mode: sap.m.ListMode.SingleSelectMaster,
										selectionChange: [oController.onBPRefSelect, oController],
										columns: [
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefGroup}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefCGroup}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefSOrg}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefDChl}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefDv}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefPartner}"
												})
											}),
											new Column({
												header: new sap.m.Text({
													text: "{i18n>BPRefDescription}"
												})
											})
										],
										items: {
											path: "BPRefModel>/",
											template: new ColumnListItem({
												cells: [
													new sap.m.Text({
														text: "{BPRefModel>AccountGroup}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>CustomerGroup}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>SalesOrganisation}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>DistributionChannel}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>Division}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>BusinessPartnerRef}"
													}),
													new sap.m.Text({
														text: "{BPRefModel>Description}"
													})
												]
											})
										}
									})
								})
							]
						})
					],
					buttons: [
						new sap.m.Button({
							text: "{i18n>createCustomer}",
							press: [oController.onCreateCustomer, oController],
							enabled: "{customerSearchModel>/viewData/createButtonEnabled}"
						}), new sap.m.Button({
							press: [oController.onCancelDlg, oController],
							text: "{i18n>reset}"
						})
					]
				});

				return createCustomerDialog;
			}
		});
	});