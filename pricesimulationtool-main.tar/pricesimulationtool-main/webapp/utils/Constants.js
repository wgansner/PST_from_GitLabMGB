jQuery.sap.declare("ch.migrol.oi.PriceSimulationTool.utils.Constants");

window.ch.migrol.oi.PriceSimulationTool.utils.Constants = {

	refreshDelays: [3000, 3000, 5000],
	maxTableSize: 1000,
	emptyKey: "EMPTY_KEY",
	stdGroupTypeSeparator: ":.:",
	
	SymScreen: {
		BUT: "BUT",		//Bren- und Treibstoffe 
		SUT: "SUA",		//Sales Und Anlagen  		
		GLB: "GLB"		//Global
	},
	
	BUT_ElemId: {
			
		SALE_ORG_ID : "k_SOrg",
		DIST_CHANNEL_ID: "k_DChan",	
		DIVISION_ID	: "k_Division",
		SALES_OFFICE_ID	: "k_SOffice",
		SALES_GROUP_ID : "k_SGroup",
		MAT_UNIT_ID : "UoM"
		
	}
	
};