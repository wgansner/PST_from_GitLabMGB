sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/base/util/ObjectPath"
], function (JSONModel, Device, ObjectPath) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createFLPModel: function () {
			var fnGetUser = ObjectPath.get("sap.ushell.Container.getUser"),
				bIsShareInJamActive = fnGetUser ? fnGetUser().isJamActive() : false,
				oModel = new JSONModel({
					isShareInJamActive: bIsShareInJamActive
				});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		setInitialPreisModel: function (selectedTab) {
			var oPreisModel = sap.ui.getCore().getModel("oPreisModel");
			if (!oPreisModel) {
				oPreisModel = new JSONModel();
			}
			var data = {
				selectedTab: selectedTab,
				s_LinkTelSaleTrans: "",
				s_LinkTelSaleTransGUID: "",
				s_LinkColOrderTrans: "",
				s_LinkColOrderTransGUID: "",
				s_LinkContrCreTrans: "",
				s_LinkContrCreTransGUID: "",
				SystemId: "",
				SystemClnt: "",
				enableTelephoneSale: false,
				enableCollectiveOrder: false,
				enableContractCreation: false,
				showValidation: false,
				showValidationEquipment: false,
				CustomerCreationEnabled: true,
				SaveDataEnabled: false,
				generalMandatory: {
					SalesOrganisation: true,
					DistributionChannel: true,
					Division: true,
					SalesOffice: false,
					SalesGroup: false,
					Auftragsgrund: true,
					Bestellkanal: true
				},
				general: {
					SalesOrganisation: "",
					DistributionChannel: "",
					Division: "",
					SalesOffice: "",
					SalesGroup: "",
					Auftragsgrund: "",
					Bestellkanal: "",
					k_in_Termingeschaeft: false,
					k_in_Regionenzuschlag: false,
					k_in_Provisionsrelevant: false,
					k_in_BenZusch: false,
					k_in_Expresszuschlag: false,
					k_in_DinstZusch: false,
					k_in_MyClimate: false,
					k_in_GenLiefertermin: false
				},
				butView: {
					PostalCodeEnabled: true,
					SoldToPartyEnabled: true,
					itemSelected: false,
					MaterialName1: "",
					MaterialName2: "",
					SoldToPartyName: "",
					PostalCodeCity: ""
				},
				butMandatory: {
					PostalCode: true,
					SoldToParty: true,
					MaterialNumber1: true,
					AltMaterialNumber: false,
					Quantity: true,
					UoM: true,
					DeliveryDateFrom: true,
					DeliveryDateTo: true,
					AltDeliveryDateFrom: false,
					AltDeliveryDateTo: false
				},
				but: {
					PostalCode: "",
					SoldToParty: "",
					MaterialNumber1: "",
					AltMaterialNumber: "",
					Quantity: "",
					UoM: "",
					DeliveryDateFrom: "",
					DeliveryDateTo: "",
					AltDeliveryDateFrom: "",
					AltDeliveryDateTo: ""
				},
				suaView: {
					PostalCodeEnabled: true,
					SoldToPartyEnabled: true,
					itemSelected: false,
					MaterialName1: "",
					MaterialName2: "",
					MaterialName3: "",
					PostalCodeCity: "",
					EquipmentSizeDescr: ""
				},
				suaMandatory: {
					PostalCode: true,
					SoldToParty: true,
					ShipToParty: true,
					Equipment: false,
					Country: false,
					MaterialNumber1: true,
					MaterialNumber2: false,
					MaterialNumber3: false,
					Quantity1: true,
					Quantity2: false,
					Quantity3: false,
					UoM1: true,
					UoM2: false,
					UoM3: false,
					CouponeCode1: false,
					CouponeCode2: false,
					CouponeCode3: false,
					DeliveryDateFrom: true,
					DeliveryDateTo: true
				},
				equipmentMandatoryTank: {
					EquipCategory: true,
					VolumeUnit: true,
					VolumeTotal: true,
					TankCount: true,
					Lagergut: true,
					TankSize: true
				},
				equipmentMandatoryBoiler: {
					EquipCategory: true,
					BoilerVolume: true,
					BoilerSize: true
				},
				sua: {
					Abteilung: "SUA",
					PostalCode: "",
					SoldToParty: "",
					ShipToParty: "",
					Equipment: "",
					EquipCategory: "",
					VolumeUnit: "",
					VolumeTotal: "",
					TankCount: "",
					BoilerVolume: "",
					BoilerSize: "",
					Lagergut: "",
					TankSize: "",
					Country: "",
					MaterialNumber1: "",
					MaterialNumber2: "",
					MaterialNumber3: "",
					Quantity1: "",
					Quantity2: "",
					Quantity3: "",
					UoM1: "",
					UoM2: "",
					UoM3: "",
					CouponeCode1: "",
					CouponeCode2: "",
					CouponeCode3: "",
					DeliveryDateFrom: "",
					DeliveryDateTo: ""
				},
				glbView: {
					PostalCodeEnabled: true,
					PostalCodeCity: "",
					SoldToPartyEnabled: true,
					itemSelected: false,
					SoldToPartyName: ""
				},
				glbMandatory: {
					AltDeliveryDateFrom: false,
					AltDeliveryDateTo: false,
					MaterialNumber2: false,
					Country: false,
					DeliveryDateFrom: true,
					DeliveryDateTo: true,
					MaterialNumber1: true,
					Quantity: true,
					SoldToParty: true,
					PostalCode: true,
					UoM: true
				},
				glb: {
					Abteilung: "GLB",
					AltDeliveryDateFrom: "",
					AltDeliveryDateTo: "",
					MaterialNumber2: "",
					Country: "",
					DeliveryDateFrom: "",
					DeliveryDateTo: "",
					MaterialNumber1: "",
					PostalCode: "",
					Quantity: "",
					SoldToParty: "",
					UoM: ""
				}
			};

			oPreisModel.setData(data);
			sap.ui.getCore().setModel(oPreisModel, "oPreisModel");

			return sap.ui.getCore().getModel("oPreisModel");
		},

		setInitialPreisModelGeneralData: function () {
			var data = {
				k_in_Termingeschaeft: false,
				k_in_Regionenzuschlag: false,
				k_in_Provisionsrelevant: false,
				k_in_BenZusch: false,
				k_in_Expresszuschlag: false,
				k_in_DinstZusch: false,
				k_in_MyClimate: false,
				k_in_GenLiefertermin: false
			};

			$.each(data, function (key, val) {
				sap.ui.getCore().getModel("oPreisModel").setProperty("/general/" + key, val);
			});

		},

		setInitialF4Model: function () {
			var f4Model = new JSONModel();

			var data = {
				customer: {},
				material: {},
				units: {}
			};

			f4Model.setData(data);
			return f4Model;
		},

		setInitialEquipmentModel: function () {
			var equipmentModel = sap.ui.getCore().getModel("equipmentModel");
			if (!equipmentModel) {
				equipmentModel = new JSONModel();
			}

			var data = {
				results: []
			};

			equipmentModel.setData(data);
			sap.ui.getCore().setModel(equipmentModel, "equipmentModel");
			return sap.ui.getCore().getModel("equipmentModel");
		},

		setInitialCustomerTitleModel: function () {
			var customerTitleModel = sap.ui.getCore().getModel("customerTitleModel");
			if (!customerTitleModel) {
				customerTitleModel = new JSONModel();
			}

			var data = {
				results: []
			};

			customerTitleModel.setData(data);
			sap.ui.getCore().setModel(customerTitleModel, "customerTitleModel");
			return sap.ui.getCore().getModel("customerTitleModel");
		},

		setInitialLanguageModel: function () {
			var languageModel = sap.ui.getCore().getModel("languageModel");
			if (!languageModel) {
				languageModel = new JSONModel();
			}

			var data = {
				results: []
			};

			languageModel.setData(data);
			sap.ui.getCore().setModel(languageModel, "languageModel");
			return sap.ui.getCore().getModel("languageModel");
		},

		setInitialCustomerSearchModel: function () {
			var customerSearchModel = sap.ui.getCore().getModel("customerSearchModel");
			if (!customerSearchModel) {
				customerSearchModel = new JSONModel();
			}

			var data = {
				selectedBPRef: {
					AccountGroup: "",
					CustomerGroup: "",
					SalesOrganisation: "",
					DistributionChannel: "",
					Division: "",
					SalesDistrict: "",
					BusinessPartnerRef: ""
				},
				parameters: {
					Partner: "",
					Title: "",
					NameFirst: "",
					NameLast: "",
					PostalCode: "",
					Region: "",
					Country: "",
					City: "",
					Street: "",
					HouseNo: "",
					Telephone1: "",
					Telephone2: "",
					CustomerGroup: "",
					SalesDistrict: "",
					SalesOrganisation: "",
					DistributionChannel: "",
					Division: "",
					SalesGroup: "",
					SalesOffice: "",
					Email: "",
					Language: "",
					Currency: "",
					SearchTerm: ""
				},
				viewData: {
					bpRefExpanded: true,
					submitButtonEnabled: false,
					createButtonEnabled: false,
					showValidation: false
				},
				results: []
			};
			customerSearchModel.setData(data);
			sap.ui.getCore().setModel(customerSearchModel, "customerSearchModel");

			return sap.ui.getCore().getModel("customerSearchModel");
		},

		setInitialAddressSuggestionSearchModel: function () {
			var addressSuggestionSearchModel = sap.ui.getCore().getModel("addressSuggestionSearchModel");
			if (!addressSuggestionSearchModel) {
				addressSuggestionSearchModel = new JSONModel();
			}
			var data = {
				parameters: {
					Percent: "75"
				}
			};
			addressSuggestionSearchModel.setData(data);
			sap.ui.getCore().setModel(addressSuggestionSearchModel, "addressSuggestionSearchModel");
			return sap.ui.getCore().getModel("addressSuggestionSearchModel");
		},

		setInitialUoMModel: function () {
			var unitOfMeasureModel = sap.ui.getCore().getModel("unitOfMeasureModel");
			if (!unitOfMeasureModel) {
				unitOfMeasureModel = new JSONModel();
			}

			var data = {
				but: [],
				sua: {
					material1: [],
					material2: [],
					material3: []
				},
				glb: []
			};
			unitOfMeasureModel.setData(data);
			sap.ui.getCore().setModel(unitOfMeasureModel, "unitOfMeasureModel");

			return unitOfMeasureModel;
		},

		setInitialShiptToModel: function () {
			var shipToModel = sap.ui.getCore().getModel("shipToModel");
			if (!shipToModel) {
				shipToModel = new JSONModel();
			}

			var data = {
				results: [],
				abladMax: 5
			};

			shipToModel.setData(data);
			sap.ui.getCore().setModel(shipToModel, "shipToModel");

			return sap.ui.getCore().getModel("shipToModel");
		},

		getInitialShipToTablePosition: function () {
			var shipToModel = sap.ui.getCore().getModel("shipToModel");
			var results = shipToModel.getProperty("/results");
			var selectedTab = sap.ui.getCore().getModel("oPreisModel").getProperty("/selectedTab");
			var mengeGesamt = parseFloat(sap.ui.getCore().getModel("oPreisModel").getProperty("/" + selectedTab + "/Quantity") || 0);

			var mengeSum = 0;
			$.each(results, function (key, val) {
				mengeSum = mengeSum + parseFloat(val.Menge);
			});

			var menge = mengeSum >= mengeGesamt ? 0 : mengeGesamt - mengeSum;

			var postalCode = sap.ui.getCore().getModel("oPreisModel").getProperty("/" + selectedTab + "/PostalCode");

			var oNewPosition = {
				PLZ: postalCode,
				ShipToPartyCity: "",
				KunWe: sap.ui.getCore().getModel("oPreisModel").getProperty("/" + selectedTab + "/SoldToParty"),
				KunWeStreet: "",
				Ablad: 1,
				Menge: menge,
				Meins: sap.ui.getCore().getModel("oPreisModel").getProperty("/" + selectedTab + "/UoM"),
				CustomerGroup: "",
				CustomerGroupName: "",
				CampCode: "",
				CampCodeC: "",
				mandatory: {
					PLZ: true,
					KunWe: true,
					KunWeStreet: false,
					Menge: true,
					Meins: true,
					CustomerGroup: false,
					CouponCode: false
				}
			};

			return oNewPosition;
		},

		setInitialPostalCodeModel: function () {
			var postalCodeModel = sap.ui.getCore().getModel("postalCodeModel");
			if (!postalCodeModel) {
				postalCodeModel = new JSONModel();
			}

			var data = {
				results: [],
				abladMax: 5
			};

			postalCodeModel.setData(data);
			sap.ui.getCore().setModel(postalCodeModel, "postalCodeModel");

			return sap.ui.getCore().getModel("postalCodeModel");
		},

		getInitialPostalCodeTablePosition: function () {
			var postalCodeModel = sap.ui.getCore().getModel("postalCodeModel");
			var results = postalCodeModel.getProperty("/results");
			var selectedTab = sap.ui.getCore().getModel("oPreisModel").getProperty("/selectedTab");
			var mengeGesamt = parseFloat(sap.ui.getCore().getModel("oPreisModel").getProperty("/" + selectedTab + "/Quantity") || 0);

			var mengeSum = 0;
			$.each(results, function (key, val) {
				mengeSum = mengeSum + parseFloat(val.Quantity);
			});
			var menge = mengeSum >= mengeGesamt ? 0 : mengeGesamt - mengeSum;

			var initialPosition = {
				PostalCode: "",
				CouponeCode: "",
				Anzahl: 1,
				Quantity: menge,
				UoM: sap.ui.getCore().getModel("oPreisModel").getProperty("/" + selectedTab + "/UoM"),
				mandatory: {
					PostalCode: true,
					CouponCode: false,
					Quantity: true,
					UoM: true
				}
			};

			return initialPosition;
		},

		setInitialLagergutModel: function () {
			var lagergutModel = sap.ui.getCore().getModel("lagergutModel");
			if (!lagergutModel) {
				lagergutModel = new JSONModel();
			}

			var data = {
				results: []
			};

			lagergutModel.setData(data);
			sap.ui.getCore().setModel(lagergutModel, "lagergutModel");

			return sap.ui.getCore().getModel("lagergutModel");
		},

		setInitialBoilerSizeModel: function () {
			var boilerSizeModel = sap.ui.getCore().getModel("boilerSizeModel");
			if (!boilerSizeModel) {
				boilerSizeModel = new JSONModel();
			}

			var data = {
				results: []
			};

			boilerSizeModel.setData(data);
			sap.ui.getCore().setModel(boilerSizeModel, "boilerSizeModel");

			return sap.ui.getCore().getModel("boilerSizeModel");
		},

		setInitialTankSizeModel: function () {
			var tankSizeModel = sap.ui.getCore().getModel("tankSizeModel");
			if (!tankSizeModel) {
				tankSizeModel = new JSONModel();
			}

			var data = {
				results: []
			};

			tankSizeModel.setData(data);
			sap.ui.getCore().setModel(tankSizeModel, "tankSizeModel");

			return sap.ui.getCore().getModel("tankSizeModel");
		},

		setInitialPreisResultModel: function () {
			var preisResultModel = sap.ui.getCore().getModel("preisResultModel");
			if (!preisResultModel) {
				preisResultModel = new JSONModel();
			}

			var data = {
				results: [],
				nettoPreisGesamt: 0,
				bruttoPreisGesamt: 0,
				telSaleButtonEnabled: false
			};

			preisResultModel.setData(data);
			sap.ui.getCore().setModel(preisResultModel, "preisResultModel");

			return sap.ui.getCore().getModel("preisResultModel");
		},

		setInitialCalculationModel: function () {
			var calculationModel = sap.ui.getCore().getModel("calculationModel");
			if (!calculationModel) {
				calculationModel = new JSONModel();
			}

			var data = {};

			calculationModel.setData(data);
			sap.ui.getCore().setModel(calculationModel, "calculationModel");

			return sap.ui.getCore().getModel("calculationModel");
		},

		setInitialBPSearchRuleModel: function () {
			var businessPartnerSearchRuleModel = sap.ui.getCore().getModel("businessPartnerSearchRuleModel");
			if (!businessPartnerSearchRuleModel) {
				businessPartnerSearchRuleModel = new JSONModel();
			}

			var data = {
				Partner: false,
				Title: false,
				NameFirst: false,
				NameLast: false,
				PostalCode: false,
				Region: false,
				Country: false,
				City: false,
				Street: false,
				HouseNo: false,
				Telephone1: false,
				Telephone2: false,
				CustomerGroup: false,
				SalesDistrict: false,
				SalesOrganisation: false,
				DistributionChannel: false,
				Division: false,
				SalesGroup: false,
				SalesOffice: false,
				Email: false,
				Language: false,
				Currency: false
			};

			businessPartnerSearchRuleModel.setData(data);
			sap.ui.getCore().setModel(businessPartnerSearchRuleModel, "businessPartnerSearchRuleModel");

			return sap.ui.getCore().getModel("businessPartnerSearchRuleModel");
		},

		setInitialBPMandatoryCreateModel: function () {
			var businessPartnerCreateMandatoryModel = sap.ui.getCore().getModel("businessPartnerCreateMandatoryModel");
			if (!businessPartnerCreateMandatoryModel) {
				businessPartnerCreateMandatoryModel = new JSONModel();
			}

			var data = {
				Partner: false,
				Title: false,
				NameFirst: false,
				NameLast: false,
				PostalCode: false,
				Region: false,
				Country: false,
				City: false,
				Street: false,
				HouseNo: false,
				Telephone1: false,
				Telephone2: false,
				CustomerGroup: false,
				SalesDistrict: false,
				SalesOrganisation: false,
				DistributionChannel: false,
				Division: false,
				SalesGroup: false,
				SalesOffice: false,
				Email: false,
				Language: false,
				Currency: false
			};

			businessPartnerCreateMandatoryModel.setData(data);
			sap.ui.getCore().setModel(businessPartnerCreateMandatoryModel, "businessPartnerCreateMandatoryModel");

			return sap.ui.getCore().getModel("businessPartnerCreateMandatoryModel");
		}

	};
});