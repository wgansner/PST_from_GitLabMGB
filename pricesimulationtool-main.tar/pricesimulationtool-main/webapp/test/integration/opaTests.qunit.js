/* global QUnit */

QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function() {
	"use strict";

	sap.ui.require([
		"ch/migrol/oi/PriceSimulationTool/test/integration/AllJourneys"
	], function() {
		QUnit.start();
	});
});