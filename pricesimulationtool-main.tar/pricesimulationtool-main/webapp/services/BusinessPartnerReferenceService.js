sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;
			
			return service;
		},

		getBusinessPartnerReference: function () {
			var deferred = $.Deferred();

			service.oModel.read("/BusinessPartnerReferenceSet", {
				success: function (oData) {
					service.controller.setModel(new JSONModel(oData.results), "BPRefModel");
					
					deferred.resolve(oData.results);
				}
			});

			return deferred.promise();

		}
	};
});