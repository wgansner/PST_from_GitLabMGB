sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;
			service.telSaleUrl = null;
			service.telSaleSystemId = null;
			service.telSaleSystemClnt = null;
			
			service.getTelephoneSaleLink("", "");

			return service;
		},

		getTelephoneSaleLink: function (sSystemId, sSystemClnt) {
			/*
			service.oModel.read("/TelesalesURLSet(SystemId='" + sSystemId + "',SystemClnt='" + sSystemClnt + "')", {
				success: function (oData) {
					service.telSaleUrl = oData.Url;
					service.telSaleSystemId = oData.SystemId;
					service.telSaleSystemClnt = oData.SystemClnt;
				},
				error: function (oError) {
					jQuery.sap.log.error(oError);
				}
			});
			*/
			var href = window.location.href;
			var hash = "/sap/";
			var stringArray = href.split(hash);
			service.telSaleUrl = stringArray[0] + "/sap/bc/gui/sap/its/webgui?" + "&~TRANSACTION=%2aZOI_PRSS_VA01%20" ;
		},
		
		createPreisSimulationLink: function(guid, parameters) {
			var finalUrl = service.telSaleUrl + "P_GUID=" + guid;
			$.each(parameters, function(key, val){
				finalUrl = finalUrl + ";" + key + "=" + val;
			});
			
			service.controller.getModel("oPreisModel").setProperty("/s_LinkTelSaleTransGUID", finalUrl);
		}
	};
});