sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;
			service.oPreisModel = service.controller.getModel("oPreisModel");

			return service;
		},

		getBestellkanalSet: function () {
			var deferred = $.Deferred();

			service.oModel.read("/BestellkanalF4Set", {
				success: function (oData) {
					var aResults = [{
						Bestellkanal: "--",
						Name: "--"
					}];
					var selectedKey = "--";
					$.each(oData.results, function (key, val) {
						aResults.push(val);
						if (val.Default) {
							selectedKey = val.Bestellkanal;
						}
					});
					service.oPreisModel.setProperty("/general/Bestellkanal", selectedKey);
					var bestellKanalModel = new JSONModel(aResults);
					service.controller.setModel(bestellKanalModel, "bestellKanalModel");
					deferred.resolve(aResults);
				}
			});

			return deferred.promise();

		}
	};
});