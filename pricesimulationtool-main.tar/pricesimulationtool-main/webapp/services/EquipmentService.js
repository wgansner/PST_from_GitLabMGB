sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		getEquipmentSet: function () {
			var deferred = $.Deferred();
			var selectedTab = service.controller.getModel("oPreisModel").getProperty("/selectedTab");
			var equipment = service.controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/Equipment");
			var equipCategory = service.controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/EquipCategory");
			var shipToParty = service.controller.getModel("oPreisModel").getProperty("/" + selectedTab + "/ShipToParty");
			var aFilters = [];

			if (equipCategory !== "") {
				aFilters.push(new Filter("EquipCategory", FilterOperator.EQ, equipCategory));
			}
			if (equipment !== "") {
				aFilters.push(new Filter("EquipCategory", FilterOperator.Contains, equipment));
			}
			if (shipToParty !== "") {
				aFilters.push(new Filter("ShipToParty", FilterOperator.EQ, shipToParty));
			}

			service.oModel.read("/EquipmentF4Set", {
				filters: aFilters,
				success: function (oData) {
					service.controller.getModel("equipmentModel").setProperty("/results/", oData.results);
					deferred.resolve(oData.results);
				}
			});

			return deferred.promise();

		},
		
		createEquipment: function() {
			var deferred = $.Deferred();
			var preisModelData = service.controller.getModel("oPreisModel").getData();
			
			var equipmentCategory = preisModelData.sua.EquipCategory;
			var parameters = {
				"EquipCategory": equipmentCategory,
				"ShipToParty": preisModelData.sua.ShipToParty
			};
			switch(equipmentCategory){
				case "T":
					parameters.TankCount = preisModelData.sua.TankCount;
					parameters.TankSize = preisModelData.sua.TankSize;
					parameters.VolumeTotal = preisModelData.sua.VolumeTotal;
					parameters.VolumeUnit = preisModelData.sua.VolumeUnit;
					parameters.Lagergut = preisModelData.sua.Lagergut;
					break;
				case "C":
					parameters.BoilerVolume = preisModelData.sua.BoilerVolume;
					parameters.BoilerSize = preisModelData.sua.BoilerSize;
					break;
			}
			
			service.oModel.create("/EquipmentCreateSet", parameters, {
				success: function (oData, oResponse) {
					deferred.resolve(oData);
				},
				error: function(){
					// oGlobalBusyDialog.close();
				}
			});
			
			return deferred.promise();
		},
		
		getEquipmentSize: function(){
			var deferred = $.Deferred();
			var equipCategory = service.controller.getModel("oPreisModel").getProperty("/sua/EquipCategory");
			var volumeUnit  = service.controller.getModel("oPreisModel").getProperty("/sua/VolumeUnit");
			var tankCount = service.controller.getModel("oPreisModel").getProperty("/sua/TankCount");
			var boilerVolume = service.controller.getModel("oPreisModel").getProperty("/sua/BoilerVolume");
			var volumeTotal = service.controller.getModel("oPreisModel").getProperty("/sua/VolumeTotal");
			
			service.oModel.read("/EquipmentSizeSet(EquipCategory='" + equipCategory + "',BoilerVolume='" + boilerVolume + "',VolumeUnit='" + volumeUnit + "',VolumeTotal='" + volumeTotal + "',TankCount='" + tankCount + "')", {
				success: function (oData) {
				//	service.controller.getModel("equipmentModel").setProperty("/results/", oData.results);
					deferred.resolve(oData);
				},
				error: function(){
					deferred.reject();
				}
			});
			
			return deferred.promise();
		},
		
		checkMandatoryFields: function(){
			var preisModel = service.controller.getModel("oPreisModel");
			var equipCategory = service.controller.getModel("oPreisModel").getProperty("/sua/EquipCategory");              
			var mandatoryFields ;//= preisModel.getProperty("/equipmentMandatory");
			var result = true;
			var oResourceBundle = service.controller.getModel("i18n").getResourceBundle();
			preisModel.setProperty("/showValidation", false);
			if ( equipCategory === 'C'){
				mandatoryFields = preisModel.getProperty("/equipmentMandatoryBoiler");
				service.controller.oMessageManager.removeAllMessages();
				$.each(mandatoryFields, function (key, val) {
					if (val && preisModel.getProperty("/sua/" + key) === "") {
						result = false;
						preisModel.setProperty("/showValidationEquipment", true);

						var fieldLabel = oResourceBundle.getText(key);
						var messageText = oResourceBundle.getText("missingMessage", fieldLabel);

						service.controller.oMessageManager.addMessages(
							new sap.ui.core.message.Message({
								message: messageText,
								type: "Error",
								processor: service.controller.oMessageProcessor
							})
						);
					}
				});
			}
			else {
				if( equipCategory === 'T' ){
					mandatoryFields = preisModel.getProperty("/equipmentMandatoryTank");
					service.controller.oMessageManager.removeAllMessages();
					$.each(mandatoryFields, function (key, val) {
						if (val && preisModel.getProperty("/sua/" + key) === "") {
							result = false;
							preisModel.setProperty("/showValidationEquipment", true);

							var fieldLabel = oResourceBundle.getText(key);
							var messageText = oResourceBundle.getText("missingMessage", fieldLabel);

							service.controller.oMessageManager.addMessages(
								new sap.ui.core.message.Message({
									message: messageText,
									type: "Error",
									processor: service.controller.oMessageProcessor
								})
							);
						}
					});
				}
			}
			
		return result;
		}
	};
});