sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		getBusinessPartners: function () {
			var deferred = $.Deferred();
			var aFilters = [];
			var oPromise = service.getBusinessPartnerSearchRulesSet();
			oPromise.then(function (oResolve) {
				if (this.checkMandatoryFields()) {
					aFilters = this.createServiceFilters(this.getFilterValuesObject());
					this.oModel.read("/BusinessPartnerSearchSet", {
						filters: aFilters,
						success: function (oData) {
							this.controller.getModel("customerSearchModel").setProperty("/results/", oData.results);
							deferred.resolve(oData);
						}.bind(this)
					});
				}
			}.bind(this));
			return deferred.promise();
		},
		getFilterValuesObject: function () {
			var filterObj = {};
			filterObj.salesOrg = service.controller.getModel("oPreisModel").getProperty("/general/SalesOrganisation");
			filterObj.distributionChannel = service.controller.getModel("oPreisModel").getProperty("/general/DistributionChannel");
			filterObj.division = service.controller.getModel("oPreisModel").getProperty("/general/Division");
			return filterObj;
		},
		getCustomerSearchData: function () {
			return this.controller.getModel("customerSearchModel").getData();
		},
		createServiceFilters: function (oFilterValues) {
			var customerSearchModelData = this.getCustomerSearchData();
			var aFilters = [];
			$.each(customerSearchModelData.parameters, function (key, val) {
				if (val !== "") {
					aFilters.push(new Filter(key, FilterOperator.EQ, val));
				}
			});
			if (oFilterValues.salesOrg) {
				aFilters.push(new Filter("SalesOrganisation", FilterOperator.EQ, oFilterValues.salesOrg));
			}
			if (oFilterValues.distributionChannel) {
				aFilters.push(new Filter("DistributionChannel", FilterOperator.EQ, oFilterValues.distributionChannel));
			}
			if (oFilterValues.division) {
				aFilters.push(new Filter("Division", FilterOperator.EQ, oFilterValues.division));
			}

			return aFilters;
		},
		getBusinessPartnerSearchRulesSet: function () {
			var deferred = $.Deferred();
			var aFilters = [];
			var title = service.controller.getModel("customerSearchModel").getProperty("/parameters/Title");
			if (title) {
				aFilters.push(new Filter("Title", FilterOperator.EQ, title));
			}
			service.oModel.read("/BusinessPartnerSrchRuleSet", {
				filters: aFilters,
				success: function (oData) {
					var businessPartnerSearchRuleModel = service.controller.getModel("businessPartnerSearchRuleModel");

					$.each(oData.results, function (key, val) {
						businessPartnerSearchRuleModel.setProperty("/" + val.Fieldname, val.Mandatory);
					});

					deferred.resolve(oData);
				}
			});

			return deferred.promise();

		},
		checkMandatoryFields: function () {

			var mandatoryFields = service.controller.getModel("businessPartnerSearchRuleModel").getData();

			var customerSearchModel = service.controller.getModel("customerSearchModel");
			var result = true;
			customerSearchModel.setProperty("/viewData/showValidation", false);

			$.each(mandatoryFields, function (key, val) {
				if (val && customerSearchModel.getProperty("/parameters/" + key) === "") {
					result = false;
					customerSearchModel.setProperty("/viewData/showValidation", true);
				}
			});

			return result;

		},

		getName: function () {
			var deferred = $.Deferred();
			var preisModel = service.controller.getModel("oPreisModel");
			var selectedTab = preisModel.getProperty("/selectedTab");
			var partnerNumber = preisModel.getProperty("/" + selectedTab + "/SoldToParty");
			if (partnerNumber !== "") {
				service.oModel.read("/CustomerNameSet('" + partnerNumber + "')", {
					success: function (oData) {
						deferred.resolve(oData);
					}
				});
			} else {
				deferred.resolve({
					CustomerText: ""
				});
			}
			return deferred.promise();
		}
	};
});