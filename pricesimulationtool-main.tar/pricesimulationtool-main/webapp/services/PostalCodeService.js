sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		getPostalCode: function (postalCode, shipToParty) {
			var deferred = $.Deferred();

			if (!shipToParty) {
				shipToParty = "";
			}

			service.oModel.read("/PostalcodeCitySet(PostalCode='" + postalCode + "',ShipToParty='" + shipToParty + "')" , {
				success: function (oData) {
					deferred.resolve(oData);
				},
				error: function(){
					deferred.reject();
				}
			});

			return deferred.promise();

		}
	};
});