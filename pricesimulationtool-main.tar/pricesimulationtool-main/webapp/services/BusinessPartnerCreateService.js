sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		createCustomer: function () {
			var deferred = $.Deferred();
			var customerSearchModel = service.controller.getModel("customerSearchModel");
			var parameters = {};
			// Order of loops is important to overwrite some search parameters
			$.each(customerSearchModel.getProperty("/parameters"), function (key, val) {
				parameters[key] = val;
			});
			$.each(customerSearchModel.getProperty("/selectedBPRef"), function (key, val) {
				parameters[key] = val;
			});

			service.oModel.setHeaders({
				"X-Requested-With": "X"
			});

			var oPromise = service.getBusinessPartnerCreateMandatorySet();
			oPromise.then(function (oResolve) {
				if (this.checkMandatoryFields()) {
					var oGlobalBusyDialog = new sap.m.BusyDialog(); //Global Busy Dialog
					oGlobalBusyDialog.open(); //Open Busy Dialog
					service.oModel.create("/BusinessPartnerCreateSet", parameters, {
						success: function (oData, oResponse) {
							oGlobalBusyDialog.close();
							deferred.resolve(oData);

						}.bind(service.controller),
						error: function (oError) {
							oGlobalBusyDialog.close();
						}.bind(service.controller)
					});
				}
			}.bind(this));

			return deferred.promise();
		},

		checkMandatoryFields: function () {

			var mandatoryFields = service.controller.getModel("businessPartnerCreateMandatoryModel").getData();

			var customerSearchModel = service.controller.getModel("customerSearchModel");
			var result = true;
			customerSearchModel.setProperty("/viewData/showValidation", false);

			$.each(mandatoryFields, function (key, val) {
				if (val && customerSearchModel.getProperty("/parameters/" + key) === "") {
					result = false;
					customerSearchModel.setProperty("/viewData/showValidation", true);
				}
			});

			return result;

		},

		getBusinessPartnerCreateMandatorySet: function () {
			var deferred = $.Deferred();
			var aFilters = [];
			var title = service.controller.getModel("customerSearchModel").getProperty("/parameters/Title");
			if (title) {
				aFilters.push(new Filter("Title", FilterOperator.EQ, title));
			}
			service.oModel.read("/BusinessPartnerMandatorySet", {
				filters: aFilters,
				success: function (oData) {
					var businessPartnerCreateMandatoryModel = service.controller.getModel("businessPartnerCreateMandatoryModel");

					$.each(oData.results, function (key, val) {
						businessPartnerCreateMandatoryModel.setProperty("/" + val.Fieldname, val.Mandatory);
					});

					deferred.resolve(oData);
				}
			});

			return deferred.promise();

		}

	};
});