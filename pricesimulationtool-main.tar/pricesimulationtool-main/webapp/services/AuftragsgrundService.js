sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ch/migrol/oi/PriceSimulationTool/model/models"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator,
	Models
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;
			service.oPreisModel = service.controller.getModel("oPreisModel");

			return service;
		},

		getAuftragsgrundSet: function () {
			var deferred = $.Deferred();

			service.oModel.read("/AuftragsgrundF4Set", {
				success: function (oData) {
					var aResults = [{
						Auftragsgrund: "--",
						Name: "--"
					}];
					var selectedKey = "--";
					$.each(oData.results, function (key, val) {
						aResults.push(val);
						if (val.Default) {
							selectedKey = val.Auftragsgrund;
						}
					});
					service.oPreisModel.setProperty("/general/Auftragsgrund", selectedKey);
					var auftragsgrundModel = new JSONModel(aResults);
					service.controller.setModel(auftragsgrundModel, "auftragsgrundModel");
					deferred.resolve(aResults);
				}
			});

			return deferred.promise();

		}
	};
});