sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"ch/migrol/oi/PriceSimulationTool/utils/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (
	JSONModel,
	Constants,
	Filter,
	FilterOperator
) {
	"use strict";

	var service;

	return {

		onInit: function (oModel, controller) {
			service = this;
			service.oModel = oModel;
			service.controller = controller;

			return service;
		},

		calculate: function () {
			var pricesimulationData = {
				PreisHeaderItemBUT: [],
				PreisHeaderResultBUT: [],
				PreisHeaderMessage: []
			};

			pricesimulationData.IdPreisim = "001";
			pricesimulationData.Abteilung = "BUT";
			pricesimulationData.FirstPositionFlag = false;
			pricesimulationData.Prozess = "";
			pricesimulationData.Country = "";

			pricesimulationData.SalesOrganisation = service.controller.getModel("oPreisModel").getProperty("/general/SalesOrganisation");
			pricesimulationData.DistributionChannel = service.controller.getModel("oPreisModel").getProperty("/general/DistributionChannel");
			pricesimulationData.Division = service.controller.getModel("oPreisModel").getProperty("/general/Division");
			pricesimulationData.SalesOffice = service.controller.getModel("oPreisModel").getProperty("/general/SalesOffice");
			pricesimulationData.SalesGroup = service.controller.getModel("oPreisModel").getProperty("/general/SalesGroup");
			pricesimulationData.Auftragsgrund = service.controller.getModel("oPreisModel").getProperty("/general/Auftragsgrund");
			pricesimulationData.Bestellkanal = service.controller.getModel("oPreisModel").getProperty("/general/Bestellkanal");

			pricesimulationData.SoldToParty = service.controller.getModel("oPreisModel").getProperty("/but/SoldToParty");
			pricesimulationData.PostalCode = service.controller.getModel("oPreisModel").getProperty("/but/PostalCode");
			pricesimulationData.MaterialNumber = service.controller.getModel("oPreisModel").getProperty("/but/MaterialNumber1");
			pricesimulationData.AltMaterialNumber = service.controller.getModel("oPreisModel").getProperty("/but/AltMaterialNumber");
			pricesimulationData.DeliveryDateFrom = service.controller.getModel("oPreisModel").getProperty("/but/DeliveryDateFrom");
			pricesimulationData.DeliveryDateTo = service.controller.getModel("oPreisModel").getProperty("/but/DeliveryDateTo");
			pricesimulationData.AltDeliveryDateFrom = service.controller.getModel("oPreisModel").getProperty("/but/AltDeliveryDateFrom");
			pricesimulationData.AltDeliveryDateTo = service.controller.getModel("oPreisModel").getProperty("/but/AltDeliveryDateTo");
			pricesimulationData.Quantity = service.controller.getModel("oPreisModel").getProperty("/but/Quantity");
			pricesimulationData.UoM = service.controller.getModel("oPreisModel").getProperty("/but/UoM");

			pricesimulationData.ConditionGroup1Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_Termingeschaeft");
			pricesimulationData.ConditionGroup2Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_Provisionsrelevant");
			pricesimulationData.ConditionGroup3Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_Expresszuschlag");
			pricesimulationData.ConditionGroup4Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_MyClimate");
			pricesimulationData.ConditionGroup5Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_GenLiefertermin");
			pricesimulationData.MaterialGroup1Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_Regionenzuschlag");
			pricesimulationData.MaterialGroup2Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_BenZusch");
			pricesimulationData.MaterialGroup3Flag = service.controller.getModel("oPreisModel").getProperty("/general/k_in_DinstZusch");

			var shipToData = service.controller.getView().getModel("shipToModel").getProperty("/results");

			for (var i = 0; i < shipToData.length; i++) {
				var anzahl = ("000" + shipToData[i].Ablad).slice(-3);
				var oPreisHeaderItemBUT = {
					"Anzahl": anzahl,
					"IdPreisim": "0000000001",
					"Plant": "",
					"ItemPreissim": "000",
					"PostalCode": shipToData[i].PLZ,
					"ShipToParty": shipToData[i].KunWe,
					"ShipToPartyName": shipToData[i].KunWeStreet,
					"Quantity": "" + shipToData[i].Menge,
					"UoM": shipToData[i].Meins,
					"CouponeCode": shipToData[i].CouponCode
				};
				pricesimulationData.PreisHeaderItemBUT.push(oPreisHeaderItemBUT);
			}

			service.oModel.setHeaders({
				"X-Requested-With": "X"
			});

			var oGlobalBusyDialog = new sap.m.BusyDialog(); //Global Busy Dialog
			oGlobalBusyDialog.open(); //Open Busy Dialog
			service.oModel.create("/PreissimulationBUTSet", pricesimulationData, {
				success: function (oData, oResponse) {
					oGlobalBusyDialog.close();
					service._setResponseData(oData, oResponse);
					if (oData.SoldToParty) {
						service.controller.getModel("oPreisModel").setProperty("/SaveDataEnabled", true);
					}

					service.controller.getModel("calculationModel").setData(oData);

					service.controller.getModel("oPreisModel").attachEvent("propertyChange", service.controller.onChangePreisModel, service.controller);

				}.bind(service.controller),
				error: function (oError) {
					oGlobalBusyDialog.close();
				}.bind(service.controller)
			});
		},

		save: function () {
			var calculationData = service.controller.getModel("calculationModel").getData();
			delete calculationData["__metadata"];

			var oGlobalBusyDialog = new sap.m.BusyDialog(); //Global Busy Dialog
			oGlobalBusyDialog.open(); //Open Busy Dialog
			service.oModel.create("/PreissimulationBUTSaveSet", calculationData, {
				success: function (oData, oResponse) {
					oGlobalBusyDialog.close();

					if (oData.PreisHeaderResultBUT.results[0].IdResult !== "") {
						service._setResponseData(oData, oResponse);
						service.controller.getModel("oPreisModel").setProperty("/DataSaved", true);
					} else {
						service.controller.getModel("oPreisModel").setProperty("/DataSaved", false);
					}
				}.bind(service.controller),
				error: function (oError) {
					service.controller.getModel("oPreisModel").setProperty("/DataSaved", false);
					oGlobalBusyDialog.close();
				}.bind(service.controller)
			});
		},

		_setResponseData: function (oData, oResponse) {
			jQuery.sap.require("sap.m.MessageBox");

			var resultsTab = oData.PreisHeaderResultBUT.results;
			var messages = oData.PreisHeaderMessage.results;

			var nettoPreisGesamt = 0;
			var bruttoPreisGesamt = 0;

			service.controller.oMessageManager.removeAllMessages();

			$.each(messages, function (key, val) {
				var messageType = null;
				switch (val.MessageStatus) {
				case "S":
					messageType = "Success";
					break;
				case "W":
					messageType = "Warning";
					break;
				case "E":
					messageType = "Error";
					break;
				}
				service.controller.oMessageManager.addMessages(
					new sap.ui.core.message.Message({
						message: val.MessageText,
						type: messageType,
						processor: service.controller.oMessageProcessor
					})
				);
			});

			$.each(resultsTab, function (key, val) {
				nettoPreisGesamt = nettoPreisGesamt + Math.round(val.NetPrice * 100);
				bruttoPreisGesamt = bruttoPreisGesamt + Math.round(val.GrossPrice * 100);
			});

			nettoPreisGesamt = nettoPreisGesamt / 100;
			bruttoPreisGesamt = bruttoPreisGesamt / 100;

			service.controller.getView().getModel("preisResultModel").setProperty("/results", resultsTab);
			service.controller.getModel("preisResultModel").setProperty("/nettoPreisGesamt", nettoPreisGesamt);
			service.controller.getModel("preisResultModel").setProperty("/bruttoPreisGesamt", bruttoPreisGesamt);
		},

		checkMandatoryFields: function () {
			var shipToModel = service.controller.getModel("shipToModel");
			var preisModel = service.controller.getModel("oPreisModel");
			var mandatoryFields = preisModel.getProperty("/butMandatory");
			var mandatoryGeneralFields = preisModel.getProperty("/generalMandatory");
			// var mandatoryShipToFields = shipToModel.getProperty("/mandatory");
			var result = true;
			var oResourceBundle = service.controller.getModel("i18n").getResourceBundle();
			preisModel.setProperty("/showValidation", false);
			shipToModel.setProperty("/showValidation", false);

			service.controller.oMessageManager.removeAllMessages();
			$.each(mandatoryFields, function (key, val) {
				if (val && preisModel.getProperty("/but/" + key) === "") {
					result = false;
					preisModel.setProperty("/showValidation", true);

					var fieldLabel = oResourceBundle.getText(key);
					var messageText = oResourceBundle.getText("missingMessage", fieldLabel);

					service.controller.oMessageManager.addMessages(
						new sap.ui.core.message.Message({
							message: messageText,
							type: "Error",
							processor: service.controller.oMessageProcessor
						})
					);
				}
			});
			$.each(mandatoryGeneralFields, function (key, val) {
				if (val && preisModel.getProperty("/general/" + key) === "--") {
					result = false;
					preisModel.setProperty("/showValidation", true);

					// var fieldLabel = oResourceBundle.getText(key);
					var messageText = oResourceBundle.getText("missingMessage", key);

					service.controller.oMessageManager.addMessages(
						new sap.ui.core.message.Message({
							message: messageText,
							type: "Error",
							processor: service.controller.oMessageProcessor
						})
					);
				}
			});

			$.each(shipToModel.getProperty("/results"), function (resultKey, resultVal) {
				$.each(resultVal.mandatory, function (key, val) {
					if (key === "PLZ" && resultVal.KunWe !== "") {
						val = false;
						service.controller.getModel("shipToModel").setProperty("/results/" + resultKey + "/mandatory/PLZ", false);
					}
					if (key === "PLZ" && resultVal.KunWe === "") {
						val = true;
						service.controller.getModel("shipToModel").setProperty("/results/" + resultKey + "/mandatory/PLZ", true);
					}
					if (key === "KunWe" && resultVal.PLZ !== "") {
						val = false;
						service.controller.getModel("shipToModel").setProperty("/results/" + resultKey + "/mandatory/KunWe", false);
					}
					if (key === "KunWe" && resultVal.PLZ === "") {
						val = true;
						service.controller.getModel("shipToModel").setProperty("/results/" + resultKey + "/mandatory/KunWe", true);
					}
					if (val && resultVal[key] === "") {
						result = false;
						shipToModel.setProperty("/showValidation", true);

						var fieldLabel = oResourceBundle.getText(key);
						var messageText = oResourceBundle.getText("missingMessage", fieldLabel);

						service.controller.oMessageManager.addMessages(
							new sap.ui.core.message.Message({
								message: messageText,
								type: "Error",
								processor: service.controller.oMessageProcessor
							})
						);
					}
				});
			});

			return result;
		}
	};
});