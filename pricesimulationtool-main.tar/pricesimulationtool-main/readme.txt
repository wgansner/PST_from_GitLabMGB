 #### WELCOME ####

This is your copy of the SAPUI5 Worklist Freestyle Application Template.
You can find the template version in the .project.json - file in your workspace.

Standalone runnable files (*.html) are located in the test-folder

This application is ready for client-side build in the SAP Web IDE and deployment to ABAP/HCP repositories

For more information and documentation of all template-app features, please refer to the SAPUI5 Demo Kit:
https://sapui5.hana.ondemand.com/#docs/guide/a460a7348a6c431a8bd967ab9fb8d918.html


 #### Happy Development! ####


 #### History ####
 SAP HANA Cloud Platform Git Service 
git.hana.ondemand.com / guj77rmamz / implico / HEAD
7a23530 Bug fixing batch use by Implico Supportuser · 3 months ago master
2796849 Bug fixing about batch using by Implico Supportuser · 3 months ago
690ccce Bug fixing for Currency error by Implico Supportuser · 9 months ago
550bfe8 Bug fixing for price field by Implico Supportuser · 9 months ago
01189bb Bug fixing for The Adding of the address suggestions by Implico Supportuser · 10 months ago
d9d1c80 The Adding of the address suggestions by Implico Supportuser · 11 months ago
dc085a2 Translations S&A by Alexandru Fediuc · 2 years ago
c9a6692 Provision Relevant FR translation by Alexandru Fediuc · 2 years, 2 months ago
8f6f8b5 Translation FR (EquipmentLagergut) by Alexandru Fediuc · 2 years, 2 months ago
45093cc Translation fix by Alexandru Fediuc · 2 years, 4 months ago
62839a6 Translation Issues by Alexandru Fediuc · 2 years, 4 months ago
3bb2db4 Text Correction Special Characters - IT, FR & DE by Alexandru Fediuc · 2 years, 5 months ago
f1c07ce Mandatory Fields - Customer Creation by Alexandru Fediuc · 2 years, 5 months ago
eac7b90 Mandatory Fields by Alexandru Fediuc · 2 years, 5 months ago
28e19a4 Equipment Size Description by Alexandru Fediuc · 2 years, 6 months ago
0b629c1 Translations by Alexandru Fediuc · 2 years, 6 months ago
0b1f413 Enable calculation S&A for no Equipment number by Alexandru Fediuc · 2 years, 9 months ago
eaefd40 Changes to equipment validation by Henrique De Figueiredo · 2 years, 10 months ago
ff6f392 Global Item Anzahl Init always with 1 by Alexandru Fediuc · 2 years, 10 months ago
6a4e8ce Changes regarding Delivery Date by Alexandru Fediuc · 2 years, 11 months ago
776b6b3 Reset Item Table GLB fix. by Alexandru Fediuc · 3 years, 2 months ago
6e1a8b5 Refactoring and various fixes by Alexandru Fediuc · 3 years, 2 months ago
c17dcad Fix "Save Enabled" for Posta Code calculation. by Alexandru Fediuc · 3 years, 2 months ago
2cbd837 CR74 V01 - Postal Code GLB & Telefon Service by Alexandru Fediuc · 3 years, 2 months ago
e657d30 Expresszuschlag added back to B&T by Alexandru Fediuc · 3 years, 4 months ago
26e74f9 Texts fix by Alexandru Fediuc · 3 years, 4 months ago
edb6dae Fixing Condition & Material Flags for S&A by Alexandru Fediuc · 3 years, 4 months ago
249679e Translation fix by Alexandru Fediuc · 3 years, 5 months ago
35484c2 Save Button enable logic - fixed by Alexandru Fediuc · 3 years, 6 months ago
b7afc49 UoM fix on GLB by Alexandru Fediuc · 3 years, 6 months ago
633e7d4 Fix issue with Postal Code S&A by Alexandru Fediuc · 3 years, 6 months ago
986b366 Change the way the Dynpro Services are called by Alexandru Fediuc · 3 years, 7 months ago
3b4f308 Fix UoM by Alexandru Fediuc · 3 years, 7 months ago
cf11ec4 Fix - Postal Code Citiy not filled when new line added to BUT by Alexandru Fediuc · 3 years, 7 months ago
495b65f Adding Global Item Quantity and fixing Anzahl Ablad by Alexandru Fediuc · 3 years, 7 months ago
844417a Small fixes by Alexandru Fediuc · 3 years, 7 months ago
cdf6160 Global Contract and various bug fixes by Alexandru Fediuc · 3 years, 7 months ago
daceb02 Contract Creation #01 by Alexandru Fediuc · 3 years, 8 months ago
3c5c48d Different Fixs for Global Tab by Alexandru Fediuc · 3 years, 8 months ago
54f3e8b Fix Equipment Service - T/C Size by Alexandru Fediuc · 3 years, 8 months ago
adea020 glb bugfix by Bastian Schmidt · 3 years, 8 months ago
ea93653 EquipmentSize Service implemented by Bastian Schmidt · 3 years, 8 months ago
f4ca5e8 Create Equipment finalized Started City to PostalCode by Bastian Schmidt · 3 years, 8 months ago
8bd6067 Equip Create bugfix by Bastian Schmidt · 3 years, 8 months ago
9519db8 EquipmentCreate by Bastian Schmidt · 3 years, 8 months ago
15ff733 glb bugfix by Bastian Schmidt · 3 years, 8 months ago
ccaebb9 anzahl bugfix by Bastian Schmidt · 3 years, 8 months ago
c1c690b Tel Sale GUID bugfix by Bastian Schmidt · 3 years, 8 months ago
ebcca41 Calculation for Globalkontrakt by Bastian Schmidt · 3 years, 8 months ago
0c1578d FCC contain -> equals by Bastian Schmidt · 3 years, 8 months ago
536435d bugfix by Bastian Schmidt · 3 years, 8 months ago
8084887 FCC bugfixes by Bastian Schmidt · 3 years, 8 months ago
9f26174 FCC Submit Button enable/disable EquipmentNo removed, when Eq. details changed by Bastian Schmidt · 3 years, 8 months ago
79a937c FCC Submit Button enable/disable EquipmentNo removed, when Eq. details changed by Bastian Schmidt · 3 years, 8 months ago
f08f9ea FCC Submit Button enable/disable EquipmentNo removed, when Eq. details changed by Bastian Schmidt · 3 years, 8 months ago
e4e2f2d Small Changes on Fast Customer Creation by Alexandru Fediuc · 3 years, 8 months ago
d88c070 bug fixing related to enable/disable buttons by Alexandru Fediuc · 3 years, 8 months ago
a28681b CollectiveOrder by Alexandru Fediuc · 3 years, 8 months ago
a74c585 Fix on BuT & SuA telefon Service by Alexandru Fediuc · 3 years, 9 months ago
723aef7 Text i18n fix by Alexandru Fediuc · 3 years, 9 months ago
8d8d7ff Business Partner Mandatory fields based on Title by Alexandru Fediuc · 3 years, 9 months ago
c304411 No activation of Telsale when no guid by Bastian Schmidt · 3 years, 9 months ago
b767b7e No activation of Telsale when no guid by Bastian Schmidt · 3 years, 9 months ago
b7145fd Merge branch 'master' by Bastian Schmidt · 3 years, 9 months ago
23a8f3b bugfix telsale by Bastian Schmidt · 3 years, 9 months ago
4a8f8ef Merge branch 'master' by Alexandru Fediuc · 3 years, 9 months ago
a54364f not important by Alexandru Fediuc · 3 years, 9 months ago
11ff21d bugfix sua service by Bastian Schmidt · 3 years, 9 months ago
be11af3 bugfix autofill name by Bastian Schmidt · 3 years, 9 months ago
cea383b autofill of customername by Bastian Schmidt · 3 years, 9 months ago
ae03dc9 Merge fix by Alexandru Fediuc · 3 years, 9 months ago
1f05a31 save Button language files by Bastian Schmidt · 3 years, 9 months ago
391e11c Merge branch 'master' by Alexandru Fediuc · 3 years, 9 months ago
4174cb0 test by Bastian Schmidt · 3 years, 9 months ago
5e429cb Merge branch 'master' by Alexandru Fediuc · 3 years, 9 months ago
f699c3a new logic by Bastian Schmidt · 3 years, 9 months ago
39b6794 Material bugfix by Bastian Schmidt · 3 years, 10 months ago
38dfb6b New Equipment fields updated autofill of shiptoparty in S&A by Bastian Schmidt · 3 years, 10 months ago
edae7dd Lagergut and Tank-/Boilersizes by Bastian Schmidt · 3 years, 10 months ago
0ade956 Mandatory chack bugfix by Bastian Schmidt · 3 years, 11 months ago
39f7218 Mandatory Check bugfix by Bastian Schmidt · 3 years, 11 months ago
db8cc6b FastCustomerCreation Dialog: Title has now an empty value. by Bastian Schmidt · 3 years, 11 months ago
4f65009 Termingeschäft Flag removed for B&T and GLB by Bastian Schmidt · 3 years, 11 months ago
933ab90 Telephone Sale bugfix Resetbutton bugfix by Bastian Schmidt · 3 years, 11 months ago
651dc3a Change on mandatory check for B&T by Bastian Schmidt · 4 years ago
381ce65 Change on mandatory check for B&T by Bastian Schmidt · 4 years ago
d59d667 bugfix B&T by Bastian Schmidt · 4 years ago
48f8e0c Auftragsgrund + Bestellkanal by Bastian Schmidt · 4 years ago
98bc2e8 bugfix S&A by Bastian Schmidt · 4 years ago
985a87a Bestellkanal and Auftragsgrund by Bastian Schmidt · 4 years ago
8bd4290 bugfix by Bastian Schmidt · 4 years ago
4a7fe91 ShipToParty F4 Dialog: added street column by Bastian Schmidt · 4 years ago
f3e3c14 Mandatory check for shipToParty table by Bastian Schmidt · 4 years ago
4ffe942 Messages updated by Bastian Schmidt · 4 years ago
e0fc9e5 Telephonesale updated by Bastian Schmidt · 4 years ago
17c45f1 Merge branch 'master' by Alexandru Fediuc · 4 years ago
7126bf2 Something you changed here .. by Alexandru Fediuc · 4 years ago
5dd3c93 global tab mapped by Bastian Schmidt · 4 years ago
3469fa0 Merge branch 'master' by Bastian Schmidt · 4 years ago
a3dd1c0 Mandatory field check for fast customer creation search by Bastian Schmidt · 4 years ago 
